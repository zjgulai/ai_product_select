import Breadcrumb from '@/components/shared/Breadcrumb';
import CategoryFilter from '@/components/shared/CategoryFilter';
import { VIDEOS_LIST } from '@/data/mockData';
import { LC } from '@/lib/lute-colors';
import { Search, Download, Star } from 'lucide-react';
import { useState } from 'react';

const TABS = ["视频热播榜", "视频热销榜"];
const TIME_RANGES = ["全部", "日", "近7天", "近30天", "自定义"];

export default function TikTokVideo() {
  const [tab, setTab] = useState(0);
  const [timeRange, setTimeRange] = useState(2);

  return (
    <div className="animate-fadeIn">
      <Breadcrumb items={["TikTok趋势", "视频"]} />
      <div className="bg-white rounded-lg shadow-lc p-3 mb-3 ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center gap-0">
          <div className="relative flex-1 max-w-[400px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#A8A29E' }} />
            <input type="text" placeholder="视频标题" className="w-full h-9 pl-9 pr-3 rounded-l-full border border-r-0 text-xs focus:outline-none" style={{ borderColor: '#EDEAE5', color: '#1C1917' }} />
          </div>
          <button className="h-9 px-6 text-white text-xs font-medium rounded-r-full transition-all hover:brightness-110" style={{ background: '#E8785A' }}>搜索</button>
        </div>
      </div>
      <div className="bg-white rounded-t-lg shadow-lc border-b px-4 pt-3 ring-1 ring-[#EDEAE5]/60">
        <div className="flex gap-6">
          {TABS.map((t, i) => (
            <button key={t} onClick={() => setTab(i)} className="pb-2.5 text-xs font-medium transition-all border-b-2"
              style={tab === i ? { color: '#E8785A', borderColor: '#E8785A' } : { color: '#A8A29E', borderColor: 'transparent' }}>{t}</button>
          ))}
        </div>
      </div>
      <CategoryFilter />
      <div className="bg-white p-3 border-b" style={{ borderColor: '#EDEAE5' }}>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <input type="checkbox" id="adOnly" className="rounded accent-[#3B82F6]" />
            <label htmlFor="adOnly" className="text-xs font-medium" style={{ color: '#78716C' }}>投流视频</label>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium" style={{ color: '#78716C' }}>发布日期:</span>
            {TIME_RANGES.map((t, i) => (
              <button key={t} onClick={() => setTimeRange(i)} className="px-3 h-7 rounded-md text-xs font-medium transition-all"
                style={timeRange === i ? { background: '#E8785A', color: '#fff' } : { background: '#FFFFFF', color: '#A8A29E' }}>{t}</button>
            ))}
          </div>
        </div>
      </div>
      <div className="bg-white rounded-b-lg shadow-lc overflow-hidden ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center justify-between p-3 border-b" style={{ borderColor: '#EDEAE5' }}>
          <h3 className="text-sm font-semibold" style={{ color: '#E8785A' }}>视频信息</h3>
          <button className="flex items-center gap-1 text-xs font-medium" style={{ color: '#E8785A' }}><Download size={12} /> 数据导出</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ background: '#FAFAF8' }}>
                {["视频信息", "近30日销量", "近30日销售额($)", "播放量", "点赞数", "互动率", "发布日期", "达人信息", "商品信息", "操作"].map((h, i) => (
                  <th key={h} className={`py-2.5 px-3 text-xs font-semibold ${i===0?'text-left w-[280px]':i===8?'text-left w-[140px]':i===9?'text-center w-[60px]':'text-right'}`} style={{ color: '#78716C' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {VIDEOS_LIST.map((item, idx) => (
                <tr key={idx} className="border-b hover:bg-[#F7F8F9] transition-colors" style={{ borderColor: '#F5F2EE' }}>
                  <td className="py-2.5 px-3">
                    <div className="flex items-center gap-2">
                      <div className="w-11 h-8 rounded flex items-center justify-center text-[10px] shrink-0 ring-1 ring-[#EDEAE5] relative overflow-hidden" style={{ background: '#FAFAF8' }}>
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="white"><path d="M8 5v14l11-7z"/></svg>
                        <span className="absolute bottom-0 right-0 text-[7px] px-1 rounded-tl" style={{ background: 'rgba(0,0,0,0.7)', color: '#fff' }}>{item.duration}</span>
                      </div>
                      <div>
                        <div className="text-xs truncate max-w-[180px]" style={{ color: '#1C1917' }} title={item.title}>{item.title}</div>
                        <div className="text-[10px]" style={{ color: '#A8A29E' }}>{item.date}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num font-semibold" style={{ color: '#1C1917' }}>{item.monthlySales.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num font-semibold" style={{ color: '#E8785A' }}>{item.monthlyRevenue.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num" style={{ color: '#1C1917' }}>{(item.views/1000000).toFixed(2)}M</td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num" style={{ color: '#1C1917' }}>{(item.likes/1000).toFixed(0)}K</td>
                  <td className="py-2.5 px-3 text-right"><span className="text-xs font-mono-num font-semibold" style={{ color: parseFloat(item.engagement) > 2 ? LC.success : parseFloat(item.engagement) > 1.3 ? '#14B8A6' : '#A8A29E' }}>{item.engagement}</span></td>
                  <td className="py-2.5 px-3 text-xs" style={{ color: '#A8A29E' }}>{item.publishDate}</td>
                  <td className="py-2.5 px-3">
                    <div className="flex items-center gap-1.5">
                      <div className="w-6 h-6 rounded-full flex items-center justify-center text-[8px] font-semibold ring-1 ring-[#EDEAE5]" style={{ background: `${'#E8785A'}10`, color: '#E8785A' }}>{item.creator[0]?.toUpperCase()}</div>
                      <span className="text-xs truncate max-w-[80px]" style={{ color: '#1C1917' }}>{item.creator}</span>
                    </div>
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="flex items-center gap-1.5">
                      <img src="/assets/products/p3.jpg" alt="" className="w-6 h-6 rounded object-cover ring-1 ring-[#EDEAE5]" />
                      <span className="text-xs truncate max-w-[80px]" style={{ color: '#1C1917' }}>{item.product}</span>
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-center"><button className="transition-colors" style={{ color: '#E0DCD6' }} onMouseEnter={e => e.currentTarget.style.color = '#E8785A'} onMouseLeave={e => e.currentTarget.style.color = '#E0DCD6'}><Star size={13} /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
