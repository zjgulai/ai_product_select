import { useState } from 'react';
import Breadcrumb from '@/components/shared/Breadcrumb';
import MiniTrend from '@/components/shared/MiniTrend';
import { Download, Flame } from 'lucide-react';

const HOT_DATA = [
  { rank: 1, keyword: "kitchen organizer", trend: [62,65,68,72,75,78,82,85,88,92], sales: 1256800, salesG: "+15.2%", revenue: 25136000, price: 20.0, rating: 4.3, reviews: 48200, competition: "高" },
  { rank: 2, keyword: "car accessories", trend: [55,58,62,65,68,72,75,78,80,82], sales: 985400, salesG: "+12.8%", revenue: 14781000, price: 15.0, rating: 4.1, reviews: 36500, competition: "高" },
  { rank: 3, keyword: "baby products", trend: [48,52,55,58,60,62,65,68,70,72], sales: 856200, salesG: "+10.5%", revenue: 17124000, price: 20.0, rating: 4.5, reviews: 52800, competition: "中高" },
  { rank: 4, keyword: "phone accessories", trend: [72,68,65,62,58,55,52,50,48,45], sales: 1125000, salesG: "-3.2%", revenue: 11250000, price: 10.0, rating: 4.0, reviews: 42000, competition: "极高" },
  { rank: 5, keyword: "home decor", trend: [42,45,48,52,55,58,60,62,65,68], sales: 625400, salesG: "+18.6%", revenue: 12508000, price: 20.0, rating: 4.4, reviews: 28500, competition: "中" },
  { rank: 6, keyword: "dog supplies", trend: [38,42,45,48,50,52,55,58,60,62], sales: 528600, salesG: "+8.4%", revenue: 10572000, price: 20.0, rating: 4.6, reviews: 31200, competition: "中高" },
  { rank: 7, keyword: "makeup tools", trend: [55,52,50,48,52,55,58,62,65,68], sales: 452800, salesG: "+6.2%", revenue: 6792000, price: 15.0, rating: 4.5, reviews: 24800, competition: "高" },
  { rank: 8, keyword: "camping gear", trend: [28,32,38,45,52,58,62,55,48,42], sales: 385600, salesG: "+25.8%", revenue: 7712000, price: 20.0, rating: 4.3, reviews: 18500, competition: "中" },
];

export default function HotMarket() {
  const [searchText, setSearchText] = useState("");
  const filtered = searchText ? HOT_DATA.filter(d => d.keyword.includes(searchText.toLowerCase())) : HOT_DATA;

  return (
    <div className="animate-fadeIn">
      <Breadcrumb items={["Amazon趋势", "热门市场"]} />
      <div className="bg-white rounded-lg shadow-lc p-4 mb-4 ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Flame size={18} style={{ color: '#DC2626' }} />
            <div>
              <h2 className="text-base font-bold" style={{ color: '#1C1917' }}>热门市场</h2>
              <p className="text-[11px] mt-0.5" style={{ color: '#A8A29E' }}>评论量较大且增长的市场 · 共 1,058,913 个</p>
            </div>
          </div>
          <div className="flex items-center gap-0">
            <input type="text" value={searchText} onChange={e => setSearchText(e.target.value)} placeholder="搜索关键词..." className="w-64 h-9 pl-4 pr-3 rounded-l-full border border-r-0 text-xs" style={{ borderColor: '#EDEAE5' }} />
            <button className="h-9 px-5 rounded-r-full text-xs font-bold" style={{ background: '#E8785A', color: '#1C1917' }}>搜索</button>
          </div>
        </div>
      </div>
      <div className="bg-white rounded-lg shadow-lc overflow-hidden ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center justify-between p-3 border-b" style={{ borderColor: '#EDEAE5' }}>
          <h3 className="text-sm font-bold" style={{ color: '#1C1917' }}>热门市场排名</h3>
          <button className="flex items-center gap-1 text-xs font-bold" style={{ color: '#E8785A' }}><Download size={12} /> 导出</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ background: '#FAFAF8' }}>
                {['排名','关键词','趋势','月销量','月销售额','均价','评分','评论数','竞争度'].map(h => <th key={h} className="py-2.5 px-3 text-[11px] font-bold" style={{ color: '#78716C' }}>{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {filtered.map((item, idx) => (
                <tr key={idx} className="border-b hover:bg-[#FAFAF8]" style={{ borderColor: '#F5F2EE' }}>
                  <td className="py-2.5 px-3"><span className="text-xs font-bold font-mono-num" style={{ color: idx < 3 ? '#E8785A' : '#A8A29E', background: idx < 3 ? '#FEF2EE' : 'transparent', width: 22, height: 22, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', borderRadius: 6 }}>{item.rank}</span></td>
                  <td className="py-2.5 px-3 text-xs font-bold" style={{ color: '#E8785A' }}>{item.keyword}</td>
                  <td className="py-2.5 px-3"><MiniTrend data={item.trend} /></td>
                  <td className="py-2.5 px-3 text-right"><div className="text-xs font-bold font-mono-num">{item.sales.toLocaleString()}</div><div className="text-[10px] font-bold" style={{ color: item.salesG.startsWith('+') ? '#16A34A' : '#DC2626' }}>{item.salesG}</div></td>
                  <td className="py-2.5 px-3 text-right text-xs font-bold font-mono-num" style={{ color: '#E8785A' }}>${item.revenue.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num">${item.price}</td>
                  <td className="py-2.5 px-3 text-right"><span className="text-xs font-bold" style={{ color: item.rating >= 4.5 ? '#16A34A' : '#14B8A6' }}>{item.rating}</span></td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num">{item.reviews.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-center"><span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: item.competition === '极高' ? '#FEE2E2' : item.competition === '高' ? '#FEF3C7' : '#DCFCE7', color: item.competition === '极高' ? '#DC2626' : item.competition === '高' ? '#E8810A' : '#16A34A' }}>{item.competition}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
