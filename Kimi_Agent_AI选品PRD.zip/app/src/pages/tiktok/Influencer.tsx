import { useState } from 'react';
import Breadcrumb from '@/components/shared/Breadcrumb';
import CategoryFilter from '@/components/shared/CategoryFilter';
import { INFLUENCERS_LIST } from '@/data/mockData';
import { LC } from '@/lib/lute-colors';
import { Heart, Flame } from 'lucide-react';
import { Search, Download, Star, X, Zap } from 'lucide-react';

const TABS = ["达人带货榜", "达人涨粉榜"];
const AVATAR_IMAGES = ["/assets/avatars/a1.jpg", "/assets/avatars/a2.jpg", "/assets/avatars/a3.jpg"];

export default function TikTokInfluencer() {
  const [tab, setTab] = useState(0);
  const [showBanner, setShowBanner] = useState(true);

  return (
    <div className="animate-fadeIn">
      <Breadcrumb items={["TikTok趋势", "达人"]} />

      {showBanner && (
        <div className="relative gradient-lc-primary rounded-lg p-5 mb-4 overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <svg width="100%" height="100%"><pattern id="g" width="30" height="30" patternUnits="userSpaceOnUse"><circle cx="15" cy="15" r="1" fill="white"/></pattern><rect width="100%" height="100%" fill="url(#g)"/></svg>
          </div>
          <button onClick={() => setShowBanner(false)} className="absolute top-2 right-2 text-white/40 hover:text-white transition-colors z-10"><X size={16} /></button>
          <div className="relative flex items-center justify-between z-10">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Zap size={18} style={{ color: '#FFD700' }} />
                <h3 className="text-lg font-bold text-white tracking-wide">AI驱动的 TK达人建联工具</h3>
              </div>
              <div className="flex items-center gap-4 text-white/70 text-xs">
                <span><Heart size={12} className="text-[#E8785A]" /> 50+亿级大卖</span>
                <span><Flame size={12} className="text-[#C84040]" /> 3W+卖家的选择</span>
              </div>
            </div>
            <button className="bg-white px-6 h-9 rounded-full text-sm font-semibold transition-all hover:bg-white/90"
              style={{ color: '#E8785A' }}>免费试用</button>
          </div>
        </div>
      )}

      {/* Search */}
      <div className="bg-white rounded-lg shadow-lc p-3 mb-3 ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center gap-0">
          <div className="relative flex-1 max-w-[400px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#A8A29E' }} />
            <input type="text" placeholder="达人名称/账号" className="w-full h-9 pl-9 pr-3 rounded-l-full border border-r-0 text-xs transition-all focus:outline-none focus:ring-1" style={{ borderColor: '#EDEAE5', color: '#1C1917' }} />
          </div>
          <button className="h-9 px-6 text-white text-xs font-medium rounded-r-full transition-all hover:brightness-110" style={{ background: '#E8785A' }}>搜索</button>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-t-lg shadow-lc border-b px-4 pt-3 ring-1 ring-[#EDEAE5]/60">
        <div className="flex gap-6">
          {TABS.map((t, i) => (
            <button key={t} onClick={() => setTab(i)}
              className="pb-2.5 text-xs font-medium transition-all border-b-2"
              style={tab === i ? { color: '#E8785A', borderColor: '#E8785A' } : { color: '#A8A29E', borderColor: 'transparent' }}>{t}</button>
          ))}
        </div>
      </div>

      <CategoryFilter />

      {/* More Filters */}
      <div className="bg-white p-3 border-b" style={{ borderColor: '#EDEAE5' }}>
        <div className="flex items-center gap-3 flex-wrap">
          {["带货数", "均播量", "粉丝量", "近30日销量"].map(f => (
            <span key={f} className="flex items-center gap-1.5">
              <span className="text-xs font-medium" style={{ color: '#78716C' }}>{f}:</span>
              <input type="text" placeholder="最小" className="w-16 h-7 border rounded px-2 text-xs" style={{ borderColor: '#EDEAE5', color: '#1C1917' }} />
              <span className="text-xs" style={{ color: '#E0DCD6' }}>-</span>
              <input type="text" placeholder="最大" className="w-16 h-7 border rounded px-2 text-xs" style={{ borderColor: '#EDEAE5', color: '#1C1917' }} />
            </span>
          ))}
          <div className="ml-auto flex gap-2">
            <button className="h-7 px-5 text-white text-xs font-medium rounded-md transition-all hover:brightness-110" style={{ background: '#E8785A' }}>查询</button>
            <button className="h-7 px-5 text-xs font-medium rounded-md border transition-all" style={{ color: '#78716C', borderColor: '#EDEAE5' }}>重置</button>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-b-lg shadow-lc overflow-hidden ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center justify-between p-3 border-b" style={{ borderColor: '#EDEAE5' }}>
          <h3 className="text-sm font-semibold" style={{ color: '#E8785A' }}>达人信息</h3>
          <div className="flex items-center gap-3">
            <button className="flex items-center gap-1 text-xs font-medium" style={{ color: '#E8785A' }}><Download size={12} /> 数据导出</button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ background: '#FAFAF8' }}>
                {["达人信息", "带货数", "均播量", "粉丝数", "近30日销量", "近30日销售额($)", "视频GPM($)", "视频数", "直播GPM($)", "直播数", "账号类型", "操作"].map((h) => (
                  <th key={h} className={`py-2.5 px-3 text-xs font-semibold ${h === '达人信息' ? 'text-left w-[200px]' : h === '操作' ? 'text-center w-[60px]' : 'text-right'}`} style={{ color: '#78716C' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {INFLUENCERS_LIST.map((item, idx) => (
                <tr key={idx} className="border-b transition-colors hover:bg-[#F7F8F9]" style={{ borderColor: '#F5F2EE' }}>
                  <td className="py-2.5 px-3">
                    <div className="flex items-center gap-2">
                      <img src={AVATAR_IMAGES[idx % AVATAR_IMAGES.length]} alt="" className="w-8 h-8 rounded-full object-cover ring-1 ring-[#EDEAE5] shrink-0" />
                      <div>
                        <div className="text-xs font-medium" style={{ color: '#1C1917' }}>{item.username}</div>
                        <div className="text-[10px] truncate max-w-[130px]" style={{ color: '#A8A29E' }}>{item.desc}</div>
                      </div>
                    </div>
                  </td>
                  {[
                    item.products, item.avgViews, item.followers,
                    item.monthlySales, item.monthlyRevenue, item.videoGPM,
                    item.videoCount, item.liveGPM || '-', item.liveCount,
                  ].map((v, ci) => (
                    <td key={ci} className={`py-2.5 px-3 text-right text-xs font-mono-num ${ci === 2 ? 'font-semibold' : ''}`} style={{ color: ci === 2 ? '#1C1917' : '#78716C' }}>
                      {typeof v === 'number' ? v.toLocaleString() : v}
                      {ci === 2 && <div className="text-[10px] font-medium" style={{ color: LC.success }}>{item.fanGrowth}</div>}
                    </td>
                  ))}
                  <td className="py-2.5 px-3">
                    <span className="text-[10px] px-2 py-0.5 rounded-full font-medium"
                      style={item.type === '店铺运营' ? { background: `${'#E8785A'}10`, color: '#E8785A' } : { background: `${'#14B8A6'}10`, color: '#14B8A6' }}>{item.type}</span>
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <button className="transition-colors" style={{ color: '#E0DCD6' }} onMouseEnter={e => e.currentTarget.style.color = '#E8785A'} onMouseLeave={e => e.currentTarget.style.color = '#E0DCD6'}><Star size={13} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
