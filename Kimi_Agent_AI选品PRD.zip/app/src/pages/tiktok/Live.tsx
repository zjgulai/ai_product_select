import Breadcrumb from '@/components/shared/Breadcrumb';
import CategoryFilter from '@/components/shared/CategoryFilter';
import { LIVES_LIST } from '@/data/mockData';
import { LC } from '@/lib/lute-colors';
import { Search, Download, Star } from 'lucide-react';
import { useState } from 'react';

const TABS = ["直播人气榜", "直播涨粉榜"];
const TIME_RANGES = ["全部", "日", "近7天", "近30天", "自定义"];

export default function TikTokLive() {
  const [tab, setTab] = useState(0);
  const [timeRange, setTimeRange] = useState(2);

  return (
    <div className="animate-fadeIn">
      <Breadcrumb items={["TikTok趋势", "直播"]} />
      <div className="bg-white rounded-lg shadow-lc p-3 mb-3 ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center gap-0">
          <div className="relative flex-1 max-w-[500px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#A8A29E' }} />
            <input type="text" placeholder="商品名称、达人名称、达人账号、直播标题" className="w-full h-9 pl-9 pr-3 rounded-l-full border border-r-0 text-xs focus:outline-none" style={{ borderColor: '#EDEAE5', color: '#1C1917' }} />
          </div>
          <button className="h-9 px-6 text-white text-xs font-medium rounded-r-full" style={{ background: '#E8785A' }}>搜索</button>
        </div>
      </div>
      <div className="bg-white rounded-t-lg shadow-lc border-b px-4 pt-3 ring-1 ring-[#EDEAE5]/60">
        <div className="flex gap-6">
          {TABS.map((t, i) => (
            <button key={t} onClick={() => setTab(i)} className="pb-2.5 text-xs font-medium transition-all border-b-2"
              style={tab === i ? { color: '#E8785A', borderColor: '#E8785A' } : { color: '#A8A29E', borderColor: 'transparent' }}>{t}</button>
          ))}
        </div>
      </div>
      <CategoryFilter />
      <div className="bg-white p-3 border-b" style={{ borderColor: '#EDEAE5' }}>
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium" style={{ color: '#78716C' }}>开播时间:</span>
          {TIME_RANGES.map((t, i) => (
            <button key={t} onClick={() => setTimeRange(i)} className="px-3 h-7 rounded-md text-xs font-medium transition-all"
              style={timeRange === i ? { background: '#E8785A', color: '#fff' } : { background: '#FFFFFF', color: '#A8A29E' }}>{t}</button>
          ))}
        </div>
      </div>
      <div className="bg-white rounded-b-lg shadow-lc overflow-hidden ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center justify-between p-3 border-b" style={{ borderColor: '#EDEAE5' }}>
          <h3 className="text-sm font-semibold" style={{ color: '#E8785A' }}>直播信息</h3>
          <button className="flex items-center gap-1 text-xs font-medium" style={{ color: '#E8785A' }}><Download size={12} /> 数据导出</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ background: '#FAFAF8' }}>
                {["直播信息", "开播时间", "累计观看人次", "最高在线人数", "总点赞数", "总回复数", "涨粉数", "达人信息", "操作"].map((h, i) => (
                  <th key={h} className={`py-2.5 px-3 text-xs font-semibold ${i===0?'text-left w-[200px]':i===1?'text-left w-[200px]':i===8?'text-center w-[60px]':'text-right'}`} style={{ color: '#78716C' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {LIVES_LIST.map((item, idx) => (
                <tr key={idx} className="border-b hover:bg-[#F7F8F9] transition-colors" style={{ borderColor: '#F5F2EE' }}>
                  <td className="py-2.5 px-3">
                    <div className="flex items-center gap-2">
                      <div className="w-10 h-8 rounded flex items-center justify-center shrink-0 ring-1 ring-[#EDEAE5]" style={{ background: '#FEF2EE' }}><span className="text-[10px]"><div className="w-2 h-2 rounded-full bg-[#DC2626] animate-pulse" /></span></div>
                      <span className="text-xs truncate max-w-[140px]" style={{ color: '#1C1917' }} title={item.title}>{item.title}</span>
                    </div>
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="text-[10px] space-y-0.5" style={{ color: '#A8A29E' }}>
                      <div>开播 {item.startTime}</div>
                      <div>结束 {item.endTime}</div>
                      <div className="font-medium" style={{ color: '#78716C' }}>时长 {item.duration}</div>
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num font-semibold" style={{ color: '#1C1917' }}>{item.viewers.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num font-semibold" style={{ color: '#1C1917' }}>{item.peakOnline.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num" style={{ color: '#1C1917' }}>{item.likes.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num" style={{ color: '#78716C' }}>{item.replies.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right"><span className="text-xs font-mono-num font-semibold" style={{ color: LC.success }}>{item.newFans.toLocaleString()}</span></td>
                  <td className="py-2.5 px-3">
                    <div className="flex items-center gap-1.5">
                      <div className="w-6 h-6 rounded-full flex items-center justify-center text-[8px] font-semibold ring-1 ring-[#EDEAE5]" style={{ background: `${'#E8785A'}10`, color: '#E8785A' }}>{item.creator[0]?.toUpperCase()}</div>
                      <div><div className="text-xs truncate max-w-[70px]" style={{ color: '#1C1917' }}>{item.creator}</div><div className="text-[10px] font-mono-num" style={{ color: '#A8A29E' }}>{(item.creatorFollowers/1000000).toFixed(0)}M粉</div></div>
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-center"><button className="transition-colors" style={{ color: '#E0DCD6' }} onMouseEnter={e => e.currentTarget.style.color = '#E8785A'} onMouseLeave={e => e.currentTarget.style.color = '#E0DCD6'}><Star size={13} /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
