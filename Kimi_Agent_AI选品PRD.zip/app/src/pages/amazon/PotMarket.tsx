import { useState } from 'react';
import Breadcrumb from '@/components/shared/Breadcrumb';
import MiniTrend from '@/components/shared/MiniTrend';
import { Download, Zap } from 'lucide-react';

const POT_DATA = [
  { rank: 1, keyword: "smart garden", trend: [12,15,18,22,28,35,42,48,55,62], sales: 125600, salesG: "+45.2%", revenue: 3768000, price: 30.0, rating: 4.2, reviews: 8200, potential: "极高" },
  { rank: 2, keyword: "solar lights outdoor", trend: [18,22,25,28,32,38,42,45,48,52], sales: 256800, salesG: "+32.8%", revenue: 5136000, price: 20.0, rating: 4.3, reviews: 12500, potential: "极高" },
  { rank: 3, keyword: "pet camera", trend: [22,25,28,30,32,35,38,42,45,48], sales: 185600, salesG: "+28.5%", revenue: 5568000, price: 30.0, rating: 4.1, reviews: 9800, potential: "高" },
  { rank: 4, keyword: "standing desk converter", trend: [15,18,20,22,25,28,32,35,38,42], sales: 98500, salesG: "+38.6%", revenue: 3940000, price: 40.0, rating: 4.4, reviews: 6500, potential: "高" },
  { rank: 5, keyword: "reusable food wrap", trend: [8,10,12,15,18,22,25,28,32,35], sales: 85600, salesG: "+52.3%", revenue: 1284000, price: 15.0, rating: 4.5, reviews: 4200, potential: "极高" },
  { rank: 6, keyword: "led mirror makeup", trend: [25,28,30,32,35,38,40,42,38,35], sales: 225600, salesG: "+15.8%", revenue: 4512000, price: 20.0, rating: 4.3, reviews: 18500, potential: "中高" },
  { rank: 7, keyword: "portable blender", trend: [32,35,38,40,42,38,35,32,30,28], sales: 185200, salesG: "-5.2%", revenue: 2780000, price: 15.0, rating: 4.0, reviews: 15200, potential: "中" },
  { rank: 8, keyword: "baby carrier ergonomic", trend: [18,20,22,25,28,32,35,38,42,45], sales: 125800, salesG: "+42.1%", revenue: 3774000, price: 30.0, rating: 4.6, reviews: 7800, potential: "高" },
];

export default function PotMarket() {
  const [searchText, setSearchText] = useState("");
  const filtered = searchText ? POT_DATA.filter(d => d.keyword.includes(searchText.toLowerCase())) : POT_DATA;

  return (
    <div className="animate-fadeIn">
      <Breadcrumb items={["Amazon趋势", "潜力市场"]} />
      <div className="bg-white rounded-lg shadow-lc p-4 mb-4 ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Zap size={18} style={{ color: '#E8785A', background: '#FFFFFF', borderRadius: 4, padding: 2 }} />
            <div>
              <h2 className="text-base font-bold" style={{ color: '#1C1917' }}>潜力市场</h2>
              <p className="text-[11px] mt-0.5" style={{ color: '#A8A29E' }}>评论量规模中等，且涨幅不错的市场 · 共 14,980 个</p>
            </div>
          </div>
          <div className="flex items-center gap-0">
            <input type="text" value={searchText} onChange={e => setSearchText(e.target.value)} placeholder="搜索关键词..." className="w-64 h-9 pl-4 pr-3 rounded-l-full border border-r-0 text-xs" style={{ borderColor: '#EDEAE5' }} />
            <button className="h-9 px-5 rounded-r-full text-xs font-bold" style={{ background: '#E8785A', color: '#1C1917' }}>搜索</button>
          </div>
        </div>
      </div>
      <div className="bg-white rounded-lg shadow-lc overflow-hidden ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center justify-between p-3 border-b" style={{ borderColor: '#EDEAE5' }}>
          <h3 className="text-sm font-bold" style={{ color: '#1C1917' }}>潜力市场排名</h3>
          <button className="flex items-center gap-1 text-xs font-bold" style={{ color: '#E8785A' }}><Download size={12} /> 导出</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ background: '#FAFAF8' }}>
                {['排名','关键词','趋势','月销量','月销售额','均价','评分','评论数','潜力'].map(h => <th key={h} className="py-2.5 px-3 text-[11px] font-bold" style={{ color: '#78716C' }}>{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {filtered.map((item, idx) => (
                <tr key={idx} className="border-b hover:bg-[#FAFAF8]" style={{ borderColor: '#F5F2EE' }}>
                  <td className="py-2.5 px-3"><span className="text-xs font-bold font-mono-num" style={{ color: idx < 3 ? '#E8785A' : '#A8A29E', background: idx < 3 ? '#FEF2EE' : 'transparent', width: 22, height: 22, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', borderRadius: 6 }}>{item.rank}</span></td>
                  <td className="py-2.5 px-3 text-xs font-bold" style={{ color: '#E8785A' }}>{item.keyword}</td>
                  <td className="py-2.5 px-3"><MiniTrend data={item.trend} color="#E8785A" /></td>
                  <td className="py-2.5 px-3 text-right"><div className="text-xs font-bold font-mono-num">{item.sales.toLocaleString()}</div><div className="text-[10px] font-bold" style={{ color: item.salesG.startsWith('+') ? '#16A34A' : '#DC2626' }}>{item.salesG}</div></td>
                  <td className="py-2.5 px-3 text-right text-xs font-bold font-mono-num" style={{ color: '#E8785A' }}>${item.revenue.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num">${item.price}</td>
                  <td className="py-2.5 px-3 text-right"><span className="text-xs font-bold" style={{ color: item.rating >= 4.5 ? '#16A34A' : '#14B8A6' }}>{item.rating}</span></td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num">{item.reviews.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-center"><span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: item.potential === '极高' ? '#E8785A30' : item.potential === '高' ? '#DCFCE7' : '#FEF3C7', color: item.potential === '极高' ? '#5A5A00' : item.potential === '高' ? '#16A34A' : '#E8810A' }}>{item.potential}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
