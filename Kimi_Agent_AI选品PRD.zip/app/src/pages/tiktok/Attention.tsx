import { useState } from 'react';
import Breadcrumb from '@/components/shared/Breadcrumb';
import { Package } from 'lucide-react';

const TABS = ["商品", "达人", "小店", "视频", "直播"];

export default function TikTokAttention() {
  const [tab, setTab] = useState(0);

  return (
    <div className="animate-fadeIn">
      <Breadcrumb items={["TikTok趋势", "关注"]} />
      <div className="bg-white rounded-lg shadow-lc p-6 ring-1 ring-[#EDEAE5]/60">
        <h2 className="text-base font-semibold mb-4" style={{ color: '#E8785A' }}>我的关注</h2>
        <div className="flex gap-6 border-b mb-8" style={{ borderColor: '#EDEAE5' }}>
          {TABS.map((t, i) => (
            <button key={t} onClick={() => setTab(i)}
              className="pb-2.5 text-xs font-medium transition-all border-b-2"
              style={tab === i ? { color: '#E8785A', borderColor: '#E8785A' } : { color: '#A8A29E', borderColor: 'transparent' }}>{t}</button>
          ))}
        </div>
        <div className="flex flex-col items-center justify-center py-20">
          <div className="w-16 h-16 rounded-lg border-2 border-dashed flex items-center justify-center mb-4" style={{ borderColor: '#EDEAE5' }}>
            <Package size={28} style={{ color: '#EDEAE5' }} />
          </div>
          <p className="text-sm font-medium" style={{ color: '#A8A29E' }}>暂无数据</p>
          <p className="text-xs mt-1" style={{ color: '#E0DCD6' }}>您关注的内容将显示在这里</p>
        </div>
      </div>
    </div>
  );
}
