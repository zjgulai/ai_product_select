import { useState } from 'react';
import Breadcrumb from '@/components/shared/Breadcrumb';
import MiniTrend from '@/components/shared/MiniTrend';

import { Download } from 'lucide-react';

const PARAM_DATA = [
  { rank: 1, keyword: "invincible", trend: [45,52,48,58,62,55,68,72,65,78], sales: 482100, salesG: "+12.3%", revenue: 18420000, revG: "+8.7%", price: 38.2, rating: 4.3, top3: "18.5%", newP: "3.2%", attrs: "waterproof,durable,portable" },
  { rank: 2, keyword: "neck massager", trend: [38,42,45,48,52,55,58,62,60,65], sales: 356800, salesG: "+18.6%", revenue: 14272000, revG: "+15.2%", price: 40.0, rating: 4.1, top3: "22.1%", newP: "4.8%", attrs: "heated,cordless,adjustable" },
  { rank: 3, keyword: "body wash", trend: [55,52,58,60,62,65,68,70,72,75], sales: 521400, salesG: "+5.4%", revenue: 8332000, revG: "+3.1%", price: 15.98, rating: 4.5, top3: "35.2%", newP: "2.1%", attrs: "natural,moisturizing,organic" },
  { rank: 4, keyword: "running shoes men", trend: [42,45,48,52,55,58,60,62,65,68], sales: 425600, salesG: "+9.8%", revenue: 29800000, revG: "+7.5%", price: 70.0, rating: 4.2, top3: "28.4%", newP: "1.8%", attrs: "breathable,lightweight,cushioned" },
  { rank: 5, keyword: "yoga mat", trend: [35,38,42,48,52,55,50,48,52,58], sales: 312500, salesG: "+14.2%", revenue: 6250000, revG: "+11.8%", price: 20.0, rating: 4.4, top3: "24.6%", newP: "3.5%", attrs: "non-slip,thick,eco-friendly" },
  { rank: 6, keyword: "wireless earbuds", trend: [62,58,55,52,50,48,45,42,40,38], sales: 685200, salesG: "-8.3%", revenue: 13704000, revG: "-10.2%", price: 20.0, rating: 4.0, top3: "42.1%", newP: "5.6%", attrs: "bluetooth,noise-cancelling,waterproof" },
  { rank: 7, keyword: "sunscreen spf 50", trend: [28,32,38,45,52,58,62,65,58,48], sales: 285600, salesG: "+22.5%", revenue: 4284000, revG: "+18.9%", price: 15.0, rating: 4.6, top3: "30.8%", newP: "2.4%", attrs: "mineral,reef-safe,oil-free" },
  { rank: 8, keyword: "portable charger", trend: [48,45,42,40,38,35,32,30,28,26], sales: 365400, salesG: "-15.2%", revenue: 7308000, revG: "-12.8%", price: 20.0, rating: 4.1, top3: "38.5%", newP: "1.2%", attrs: "fast-charge,compact,20000mah" },
];

export default function ParamTrend() {
  const [searchText, setSearchText] = useState("");
  const filtered = searchText ? PARAM_DATA.filter(d => d.keyword.includes(searchText.toLowerCase())) : PARAM_DATA;

  return (
    <div className="animate-fadeIn">
      <Breadcrumb items={["Amazon趋势", "参数趋势"]} />

      {/* Header + Search */}
      <div className="bg-white rounded-lg shadow-lc p-4 mb-4 ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-base font-bold" style={{ color: '#1C1917' }}>参数趋势</h2>
            <p className="text-[11px] mt-0.5" style={{ color: '#A8A29E' }}>含产品参数的搜索词，且增长的市场 · 共 8,427 个</p>
          </div>
          <div className="flex items-center gap-0">
            <input type="text" value={searchText} onChange={e => setSearchText(e.target.value)} placeholder="搜索关键词..."
              className="w-64 h-9 pl-4 pr-3 rounded-l-full border border-r-0 text-xs" style={{ borderColor: '#EDEAE5' }} />
            <button className="h-9 px-5 rounded-r-full text-xs font-bold" style={{ background: '#E8785A', color: '#1C1917' }}>搜索</button>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {['全部','健康','美妆','家居','电子','运动'].map((f, i) => (
            <button key={f} className="px-3 h-7 rounded-full text-[11px] font-medium transition-all"
              style={i === 0 ? { background: '#FFFFFF', color: '#fff' } : { background: '#FAFAF8', color: '#A8A29E', border: '1px solid #E2E2DE' }}>{f}</button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg shadow-lc overflow-hidden ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center justify-between p-3 border-b" style={{ borderColor: '#EDEAE5' }}>
          <h3 className="text-sm font-bold" style={{ color: '#1C1917' }}>参数趋势排名</h3>
          <button className="flex items-center gap-1 text-xs font-bold" style={{ color: '#E8785A' }}><Download size={12} /> 导出</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ background: '#FAFAF8' }}>
                {['排名','关键词','趋势','月销量','月销售额($)','均价($)','评分','TOP3占比','新品占比','产品属性'].map(h => (
                  <th key={h} className="py-2.5 px-3 text-[11px] font-bold" style={{ color: '#78716C' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((item, idx) => (
                <tr key={idx} className="border-b hover:bg-[#FAFAF8] transition-colors" style={{ borderColor: '#F5F2EE' }}>
                  <td className="py-2.5 px-3"><span className="text-xs font-bold font-mono-num" style={{ color: idx < 3 ? '#E8785A' : '#A8A29E', background: idx < 3 ? '#FEF2EE' : 'transparent', width: 22, height: 22, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', borderRadius: 6 }}>{item.rank}</span></td>
                  <td className="py-2.5 px-3 text-xs font-bold" style={{ color: '#E8785A' }}>{item.keyword}</td>
                  <td className="py-2.5 px-3"><MiniTrend data={item.trend} /></td>
                  <td className="py-2.5 px-3 text-right">
                    <div className="text-xs font-mono-num font-bold" style={{ color: '#1C1917' }}>{item.sales.toLocaleString()}</div>
                    <div className="text-[10px] font-bold" style={{ color: item.salesG.startsWith('+') ? '#16A34A' : '#DC2626' }}>{item.salesG}</div>
                  </td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num font-bold" style={{ color: '#E8785A' }}>${item.revenue.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num">${item.price}</td>
                  <td className="py-2.5 px-3 text-right"><span className="text-xs font-bold" style={{ color: item.rating >= 4.5 ? '#16A34A' : item.rating >= 4 ? '#14B8A6' : '#E8810A' }}>{item.rating}</span></td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num">{item.top3}</td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num" style={{ color: '#16A34A' }}>{item.newP}</td>
                  <td className="py-2.5 px-3">
                    <div className="flex flex-wrap gap-1">{item.attrs.split(',').map(a => <span key={a} className="text-[9px] px-1.5 py-0.5 rounded font-medium" style={{ background: '#E8785A18', color: '#5A5A00' }}>{a}</span>)}</div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
