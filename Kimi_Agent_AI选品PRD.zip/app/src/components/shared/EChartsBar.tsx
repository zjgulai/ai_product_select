import ReactECharts from 'echarts-for-react';

interface BarChartProps {
  data: { label: string; value: number }[];
  title?: string;
  color?: string;
  height?: number;
  horizontal?: boolean;
  yAxisName?: string;
}

export default function EChartsBar({ data, title, color = '#E8785A', height = 250, horizontal = false, yAxisName }: BarChartProps) {
  const option = {
    title: title ? {
      text: title,
      left: 0,
      top: 0,
      textStyle: { fontSize: 12, fontWeight: 600, color: '#78716C', fontFamily: 'Inter, sans-serif' },
    } : undefined,
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(255,255,255,0.98)',
      borderColor: '#EDEAE5',
      borderWidth: 1,
      textStyle: { color: '#1C1917', fontSize: 11 },
      axisPointer: { type: 'shadow', shadowStyle: { color: 'rgba(0,0,0,0.03)' } },
    },
    grid: { top: title ? 35 : 15, bottom: horizontal ? 20 : 30, left: horizontal ? 100 : 45, right: 15 },
    xAxis: horizontal ? {
      type: 'value',
      axisLine: { show: false },
      axisTick: { show: false },
      splitLine: { lineStyle: { color: '#F5F2EE', type: 'dashed' } },
      axisLabel: { color: '#A8A29E', fontSize: 10 },
    } : {
      type: 'category',
      data: data.map(d => d.label),
      axisLine: { lineStyle: { color: '#EDEAE5' } },
      axisTick: { show: false },
      axisLabel: { color: '#A8A29E', fontSize: 10 },
    },
    yAxis: horizontal ? {
      type: 'category',
      data: data.map(d => d.label),
      axisLine: { show: false },
      axisTick: { show: false },
      axisLabel: { color: '#78716C', fontSize: 10 },
    } : {
      type: 'value',
      name: yAxisName,
      nameTextStyle: { color: '#A8A29E', fontSize: 10 },
      axisLine: { show: false },
      axisTick: { show: false },
      splitLine: { lineStyle: { color: '#F5F2EE', type: 'dashed' } },
      axisLabel: { color: '#A8A29E', fontSize: 10 },
    },
    series: [{
      type: 'bar',
      data: data.map(d => d.value),
      barWidth: horizontal ? '50%' : '40%',
      itemStyle: {
        color,
        borderRadius: horizontal ? [0, 4, 4, 0] : [4, 4, 0, 0],
      },
      emphasis: {
        itemStyle: { shadowBlur: 8, shadowColor: color + '40' },
      },
    }],
  };

  return <ReactECharts option={option} style={{ height }} opts={{ renderer: 'canvas' }} />;
}
