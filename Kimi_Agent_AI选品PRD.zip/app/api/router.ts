import { createRouter, publicQuery } from "./middleware";
import { dataManagerRouter } from "./routers/dataManager";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  dataManager: dataManagerRouter,
});

export type AppRouter = typeof appRouter;
