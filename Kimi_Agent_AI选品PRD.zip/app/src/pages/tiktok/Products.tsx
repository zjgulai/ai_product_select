import { useState, useMemo } from 'react';
import Breadcrumb from '@/components/shared/Breadcrumb';
import CategoryFilter from '@/components/shared/CategoryFilter';
import MiniTrend from '@/components/shared/MiniTrend';
import { PRODUCTS_LIST } from '@/data/mockData';
import { LC } from '@/lib/lute-colors';
import { Search, Download, Star, ShoppingCart, ChevronLeft, ChevronRight, Filter } from 'lucide-react';

const TABS = ["商品热销榜", "商品飙升榜", "商品新品榜"];
const TIME_RANGES = ["全部", "日", "近7天", "近30天", "自定义"];
const PRODUCT_IMAGES = ["/assets/products/p1.jpg","/assets/products/p2.jpg","/assets/products/p3.jpg",
  "/assets/products/p4.jpg","/assets/products/p5.jpg","/assets/products/p6.jpg","/assets/products/p5.jpg"];

export default function TikTokProducts() {
  const [tab, setTab] = useState(0);
  const [timeRange, setTimeRange] = useState(2);
  const [searchText, setSearchText] = useState("");
  const [priceMin, setPriceMin] = useState("");
  const [priceMax, setPriceMax] = useState("");
  const [ratingMin, setRatingMin] = useState("");
  const [favorites, setFavorites] = useState<Set<number>>(new Set());
  const [showToast, setShowToast] = useState("");

  const toast = (msg: string) => { setShowToast(msg); setTimeout(() => setShowToast(""), 2000); };

  const toggleFav = (idx: number) => {
    setFavorites(prev => {
      const next = new Set(prev);
      if (next.has(idx)) { next.delete(idx); toast("已取消收藏"); }
      else { next.add(idx); toast("已添加收藏"); }
      return next;
    });
  };

  // Real working filters
  const filteredProducts = useMemo(() => {
    let data = [...PRODUCTS_LIST];
    if (tab === 1) data.sort((a, b) => parseFloat(b.salesGrowth) - parseFloat(a.salesGrowth)); // 飙升
    if (tab === 2) data = data.filter(d => d.date.startsWith("2026-03")); // 新品
    if (searchText) data = data.filter(d => d.name.toLowerCase().includes(searchText.toLowerCase()));
    if (priceMin) data = data.filter(d => (d.price || 0) >= parseFloat(priceMin));
    if (priceMax) data = data.filter(d => (d.price || 999) <= parseFloat(priceMax));
    if (ratingMin) data = data.filter(d => d.rating >= parseFloat(ratingMin));
    return data;
  }, [tab, searchText, priceMin, priceMax, ratingMin]);

  return (
    <div className="animate-fadeIn relative">
      {showToast && (
        <div className="fixed top-16 right-4 z-[200] bg-white px-4 py-2.5 rounded-lg shadow-lg ring-1 ring-[#EDEAE5] animate-slideUp">
          <span className="text-xs font-medium" style={{ color: LC.success }}>{showToast}</span>
        </div>
      )}
      <Breadcrumb items={["TikTok趋势", "商品"]} />

      {/* Search */}
      <div className="bg-white rounded-lg shadow-lc p-3 mb-3 ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center gap-0">
          <div className="relative flex-1 max-w-[400px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#A8A29E' }} />
            <input type="text" value={searchText} onChange={e => setSearchText(e.target.value)} placeholder="商品标题"
              className="w-full h-9 pl-9 pr-3 rounded-l-full border border-r-0 text-xs transition-all focus:outline-none focus:ring-1"
              style={{ borderColor: '#EDEAE5', color: '#1C1917' }} />
          </div>
          <button className="h-9 px-6 text-white text-xs font-medium rounded-r-full transition-all hover:brightness-110" style={{ background: '#E8785A' }}>搜索</button>
          {searchText && (
            <span className="ml-2 text-[10px] font-medium" style={{ color: '#A8A29E' }}>找到 {filteredProducts.length} 条</span>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-t-lg shadow-lc border-b px-4 pt-3 ring-1 ring-[#EDEAE5]/60">
        <div className="flex gap-6">
          {TABS.map((t, i) => (
            <button key={t} onClick={() => setTab(i)} className="pb-2.5 text-xs font-medium transition-all border-b-2"
              style={tab === i ? { color: '#E8785A', borderColor: '#E8785A' } : { color: '#A8A29E', borderColor: 'transparent' }}>{t}</button>
          ))}
        </div>
      </div>

      <CategoryFilter />

      {/* Time + Filters */}
      <div className="bg-white p-3 border-b" style={{ borderColor: '#EDEAE5' }}>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            {TIME_RANGES.map((t, i) => (
              <button key={t} onClick={() => setTimeRange(i)} className="px-3 h-7 rounded-md text-xs font-medium transition-all"
                style={timeRange === i ? { background: '#E8785A', color: '#fff' } : { background: '#FFFFFF', color: '#A8A29E' }}>{t}</button>
            ))}
          </div>
          <div className="w-px h-5" style={{ background: '#EDEAE5' }} />
          <div className="flex items-center gap-1.5">
            <Filter size={11} style={{ color: '#A8A29E' }} />
            <span className="text-[10px] font-medium" style={{ color: '#78716C' }}>价格:</span>
            <input type="number" value={priceMin} onChange={e => setPriceMin(e.target.value)} placeholder="$0" className="w-16 h-6 border rounded px-1.5 text-[10px]" style={{ borderColor: '#EDEAE5' }} />
            <span className="text-[10px]" style={{ color: '#E0DCD6' }}>-</span>
            <input type="number" value={priceMax} onChange={e => setPriceMax(e.target.value)} placeholder="$999" className="w-16 h-6 border rounded px-1.5 text-[10px]" style={{ borderColor: '#EDEAE5' }} />
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] font-medium" style={{ color: '#78716C' }}>评分:</span>
            <input type="number" value={ratingMin} onChange={e => setRatingMin(e.target.value)} placeholder="0" min="0" max="5" step="0.1" className="w-14 h-6 border rounded px-1.5 text-[10px]" style={{ borderColor: '#EDEAE5' }} />
          </div>
          <button onClick={() => { setPriceMin(""); setPriceMax(""); setRatingMin(""); setSearchText(""); }} className="ml-auto text-[10px] font-medium px-2 h-6 rounded transition-colors" style={{ color: '#A8A29E' }}>重置筛选</button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-b-lg shadow-lc overflow-hidden ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center justify-between p-3 border-b" style={{ borderColor: '#EDEAE5' }}>
          <h3 className="text-sm font-semibold" style={{ color: '#E8785A' }}>商品信息</h3>
          <div className="flex items-center gap-3">
            <span className="text-[10px] font-medium" style={{ color: '#A8A29E' }}>共 {filteredProducts.length} 条</span>
            <button className="flex items-center gap-1 text-xs font-medium transition-colors" style={{ color: '#E8785A' }} onClick={() => toast("数据导出中...")}>
              <Download size={12} /> 数据导出
            </button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ background: '#FAFAF8' }}>
                {["商品信息","销量","销售额($)","销量趋势","带货达人数","价格($)","评分","所属小店","操作"].map((h, i) => (
                  <th key={h} className={`py-2.5 px-3 text-xs font-semibold ${i===0?'text-left w-[280px]':i===3?'text-center w-[120px]':i===8?'text-center w-[60px]':'text-right'}`} style={{ color: '#78716C' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredProducts.map((item, idx) => (
                <tr key={idx} className="border-b transition-colors hover:bg-[#F7F8F9]" style={{ borderColor: '#F5F2EE' }}>
                  <td className="py-2.5 px-3">
                    <div className="flex items-center gap-2.5">
                      <img src={PRODUCT_IMAGES[idx % PRODUCT_IMAGES.length]} alt="" className="w-9 h-9 rounded object-cover ring-1 ring-[#EDEAE5] shrink-0" />
                      <div>
                        <div className="text-xs truncate max-w-[200px] font-medium" style={{ color: '#1C1917' }} title={item.name}>{item.name}</div>
                        <span className="text-[10px] font-medium px-1.5 py-0.5 rounded-sm mt-0.5 inline-block" style={{ background: `${'#E8785A'}08`, color: '#E8785A' }}>{item.category}</span>
                      </div>
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <div className="text-xs font-semibold font-mono-num" style={{ color: '#1C1917' }}>{item.sales.toLocaleString()}</div>
                    <div className="text-[10px] font-medium" style={{ color: item.salesGrowth.startsWith('+') ? LC.success : LC.danger }}>{item.salesGrowth}</div>
                  </td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num font-semibold" style={{ color: '#E8785A' }}>${item.revenue.toLocaleString()}</td>
                  <td className="py-2.5 px-3"><div className="flex justify-center"><MiniTrend data={item.trend} /></div></td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num" style={{ color: '#1C1917' }}>{item.influencers.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num font-semibold" style={{ color: '#1C1917' }}
                    >{'priceRange' in item ? item.priceRange : `$${item.price}`}</td>
                  <td className="py-2.5 px-3 text-right"><span className="text-xs font-mono-num font-semibold" style={{ color: item.rating >= 4.5 ? LC.success : item.rating >= 4 ? '#14B8A6' : LC.warning }}>{item.rating}</span></td>
                  <td className="py-2.5 px-3"><div className="text-xs truncate max-w-[120px]" style={{ color: '#1C1917' }}>{item.shop}</div></td>
                  <td className="py-2.5 px-3">
                    <div className="flex items-center justify-center gap-1">
                      <button onClick={() => toggleFav(idx)} className="transition-colors">
                        <Star size={13} style={{ color: favorites.has(idx) ? '#FFB800' : '#E0DCD6' }} />
                      </button>
                      <button className="transition-colors" style={{ color: '#E0DCD6' }} onMouseEnter={e => e.currentTarget.style.color = '#E8785A'} onMouseLeave={e => e.currentTarget.style.color = '#E0DCD6'}><ShoppingCart size={13} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {/* Pagination */}
        <div className="flex items-center justify-between p-3 border-t" style={{ borderColor: '#EDEAE5' }}>
          <span className="text-xs font-medium" style={{ color: '#A8A29E' }}>共 {filteredProducts.length} 条</span>
          <div className="flex items-center gap-1">
            <button className="w-7 h-7 flex items-center justify-center rounded-md border" style={{ borderColor: '#EDEAE5', color: '#A8A29E' }}><ChevronLeft size={12} /></button>
            <button className="w-7 h-7 flex items-center justify-center rounded-md text-xs font-medium text-white" style={{ background: '#E8785A' }}>1</button>
            <button className="w-7 h-7 flex items-center justify-center rounded-md border text-xs font-medium" style={{ borderColor: '#EDEAE5', color: '#78716C' }}>2</button>
            <button className="w-7 h-7 flex items-center justify-center rounded-md border" style={{ borderColor: '#EDEAE5', color: '#A8A29E' }}><ChevronRight size={12} /></button>
          </div>
        </div>
      </div>
    </div>
  );
}
