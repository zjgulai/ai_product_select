import Breadcrumb from '@/components/shared/Breadcrumb';
import CategoryFilter from '@/components/shared/CategoryFilter';
import { SHOPS_LIST } from '@/data/mockData';
import { LC } from '@/lib/lute-colors';
import { Search, Download, Star } from 'lucide-react';
import { useState } from 'react';

const TABS = ["小店热销榜", "小店飙升榜"];
const TIME_RANGES = ["全部", "日", "近7天", "近30天", "自定义"];

export default function TikTokShop() {
  const [tab, setTab] = useState(0);
  const [timeRange, setTimeRange] = useState(2);

  return (
    <div className="animate-fadeIn">
      <Breadcrumb items={["TikTok趋势", "小店"]} />
      <div className="bg-white rounded-lg shadow-lc p-3 mb-3 ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center gap-0">
          <div className="relative flex-1 max-w-[400px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#A8A29E' }} />
            <input type="text" placeholder="小店名称" className="w-full h-9 pl-9 pr-3 rounded-l-full border border-r-0 text-xs focus:outline-none focus:ring-1" style={{ borderColor: '#EDEAE5', color: '#1C1917' }} />
          </div>
          <button className="h-9 px-6 text-white text-xs font-medium rounded-r-full transition-all hover:brightness-110" style={{ background: '#E8785A' }}>搜索</button>
        </div>
      </div>
      <div className="bg-white rounded-t-lg shadow-lc border-b px-4 pt-3 ring-1 ring-[#EDEAE5]/60">
        <div className="flex gap-6">
          {TABS.map((t, i) => (
            <button key={t} onClick={() => setTab(i)} className="pb-2.5 text-xs font-medium transition-all border-b-2"
              style={tab === i ? { color: '#E8785A', borderColor: '#E8785A' } : { color: '#A8A29E', borderColor: 'transparent' }}>{t}</button>
          ))}
        </div>
      </div>
      <CategoryFilter />
      <div className="bg-white p-3 border-b" style={{ borderColor: '#EDEAE5' }}>
        <div className="flex items-center gap-2">
          {TIME_RANGES.map((t, i) => (
            <button key={t} onClick={() => setTimeRange(i)} className="px-3 h-7 rounded-md text-xs font-medium transition-all"
              style={timeRange === i ? { background: '#E8785A', color: '#fff' } : { background: '#FFFFFF', color: '#A8A29E' }}>{t}</button>
          ))}
        </div>
      </div>
      <div className="bg-white rounded-b-lg shadow-lc overflow-hidden ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center justify-between p-3 border-b" style={{ borderColor: '#EDEAE5' }}>
          <h3 className="text-sm font-semibold" style={{ color: '#E8785A' }}>小店信息</h3>
          <button className="flex items-center gap-1 text-xs font-medium" style={{ color: '#E8785A' }}><Download size={12} /> 数据导出</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ background: '#FAFAF8' }}>
                {["小店信息", "销量", "销售额($)", "动销商品数", "在售商品数", "新商品占比", "总销量", "总销售额($)", "评分", "关联达人", "卖家类型", "操作"].map(h => (
                  <th key={h} className={`py-2.5 px-3 text-xs font-semibold ${h === '小店信息' ? 'text-left w-[200px]' : h === '操作' ? 'text-center w-[60px]' : 'text-right'}`} style={{ color: '#78716C' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {SHOPS_LIST.map((item, idx) => (
                <tr key={idx} className="border-b hover:bg-[#F7F8F9] transition-colors" style={{ borderColor: '#F5F2EE' }}>
                  <td className="py-2.5 px-3">
                    <div className="flex items-center gap-2">
                      <img src="/assets/shops/s2.jpg" alt="" className="w-7 h-7 rounded object-cover ring-1 ring-[#EDEAE5]" />
                      <div>
                        <div className="text-xs font-medium" style={{ color: '#1C1917' }}>{item.name}</div>
                        <div className="text-[10px]" style={{ color: '#A8A29E' }}>{item.country} | {item.category}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-right"><div className="text-xs font-mono-num font-semibold" style={{ color: '#1C1917' }}>{item.sales.toLocaleString()}</div><div className="text-[10px] font-medium" style={{ color: LC.success }}>{item.salesGrowth}</div></td>
                  <td className="py-2.5 px-3 text-right"><div className="text-xs font-mono-num font-semibold" style={{ color: '#1C1917' }}>{item.revenue.toLocaleString()}</div><div className="text-[10px] font-medium" style={{ color: item.revenueGrowth.startsWith('+') ? LC.success : LC.danger }}>{item.revenueGrowth}</div></td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num" style={{ color: '#1C1917' }}>{item.activeProducts}</td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num" style={{ color: '#1C1917' }}>{item.totalProducts}</td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num" style={{ color: '#A8A29E' }}>{item.newRatio}</td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num font-semibold" style={{ color: '#1C1917' }}>{item.totalSales.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num font-semibold" style={{ color: '#E8785A' }}>{item.totalRevenue.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right"><span className="text-xs font-mono-num font-semibold" style={{ color: item.rating >= 4.5 ? LC.success : '#14B8A6' }}>{item.rating}</span></td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num" style={{ color: '#1C1917' }}>{item.influencers.toLocaleString()}</td>
                  <td className="py-2.5 px-3"><span className="text-[10px] px-2 py-0.5 rounded-full font-medium" style={{ background: `${'#14B8A6'}10`, color: '#14B8A6' }}>{item.type}</span></td>
                  <td className="py-2.5 px-3 text-center"><button className="transition-colors" style={{ color: '#E0DCD6' }} onMouseEnter={e => e.currentTarget.style.color = '#E8785A'} onMouseLeave={e => e.currentTarget.style.color = '#E0DCD6'}><Star size={13} /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
