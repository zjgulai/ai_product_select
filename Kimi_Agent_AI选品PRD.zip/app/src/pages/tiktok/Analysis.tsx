import { useState, useMemo } from 'react';
import Breadcrumb from '@/components/shared/Breadcrumb';
// CategoryFilter available for future use
import EChartsHeatmap from '@/components/shared/EChartsHeatmap';
import EChartsTreemap from '@/components/shared/EChartsTreemap';
import EChartsLine from '@/components/shared/EChartsLine';
import EChartsPie from '@/components/shared/EChartsPie';
import EChartsBar from '@/components/shared/EChartsBar';
import {
  ANALYSIS_KPI, INFLUENCER_MATRIX
} from '@/data/mockData';
import {
  HEATMAP_CATEGORIES, HEATMAP_MONTHS, HEATMAP_DATA,
  CATEGORY_SHARE, MONTHLY_GMV, PRICE_RANGE_TREND
} from '@/data/industryData';
import { LC } from '@/lib/lute-colors';
import { Download, TrendingUp, TrendingDown, Users, ShoppingBag, DollarSign, Package, Activity, Layers } from 'lucide-react';

const KPI_ICONS = [ShoppingBag, DollarSign, Package, DollarSign, Package, DollarSign];

export default function TikTokAnalysis() {
  const [timeRange, setTimeRange] = useState(0);
  const [heatmapMetric, setHeatmapMetric] = useState<'sales' | 'growth'>('sales');
  const [activeCategory, setActiveCategory] = useState<number | null>(null);

  // Filter heatmap data by time range
  const filteredMonths = useMemo(() => {
    if (timeRange === 0) return HEATMAP_MONTHS.slice(-7); // 近7天→最近7个月
    return HEATMAP_MONTHS; // 近30天→全部
  }, [timeRange]);

  const filteredHeatmapData = useMemo(() => {
    const monthOffset = timeRange === 0 ? 3 : 0;
    return HEATMAP_DATA
      .filter(d => d[0] >= monthOffset)
      .map(d => [d[0] - monthOffset, d[1], d[2]] as [number, number, number]);
  }, [timeRange]);

  const gmvData = useMemo(() => {
    const sliceStart = timeRange === 0 ? 3 : 0;
    return MONTHLY_GMV.slice(sliceStart).map(d => ({ x: d.month, y: d.gmv }));
  }, [timeRange]);

  return (
    <div className="animate-fadeIn">
      <Breadcrumb items={["TikTok趋势", "大盘数据"]} />

      {/* KPI Cards - Enhanced with icons */}
      <div className="bg-white rounded-lg shadow-lc p-4 ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold" style={{ color: '#E8785A' }}>数据大盘</h3>
          <div className="flex items-center gap-2">
            <div className="flex gap-0.5 p-0.5 rounded-md" style={{ background: '#FAFAF8' }}>
              {["近7天", "近30天"].map((t, i) => (
                <button key={t} onClick={() => setTimeRange(i)}
                  className="px-3 h-7 rounded text-xs font-medium transition-all duration-200"
                  style={timeRange === i ? { background: '#E8785A', color: '#fff' } : { color: '#A8A29E' }}>{t}</button>
              ))}
            </div>
            <button className="flex items-center gap-1 text-[10px] font-medium px-2 h-7 rounded border transition-colors" style={{ color: '#A8A29E', borderColor: '#EDEAE5' }}>
              <Download size={11} /> 导出
            </button>
          </div>
        </div>
        <div className="grid grid-cols-6 gap-3">
          {ANALYSIS_KPI.map((kpi, i) => {
            const Icon = KPI_ICONS[i];
            return (
              <div key={kpi.title} className="rounded-lg p-3 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lc-hover cursor-pointer group"
                style={{ background: '#FAFAF8' }}>
                <div className="flex items-center gap-1.5 mb-2">
                  <div className="w-6 h-6 rounded-md flex items-center justify-center" style={{ background: `${'#E8785A'}10` }}>
                    <Icon size={13} style={{ color: '#E8785A' }} />
                  </div>
                  <span className="text-[10px] font-medium" style={{ color: '#A8A29E' }}>{kpi.title}</span>
                </div>
                <div className="text-lg font-bold font-mono-num" style={{ color: '#E8785A' }}>{kpi.value}</div>
                <div className="text-[11px] mt-1 font-medium flex items-center gap-0.5"
                  style={{ color: kpi.up ? LC.success : LC.danger }}>
                  {kpi.up ? <TrendingUp size={10} /> : <TrendingDown size={10} />} {kpi.trend}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Category Heatmap - ECharts */}
      <div className="bg-white rounded-lg shadow-lc p-4 mt-4 ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center justify-between mb-1">
          <div>
            <h3 className="text-sm font-semibold" style={{ color: '#E8785A' }}>品类热力图</h3>
            <p className="text-[11px] mt-0.5" style={{ color: '#A8A29E' }}>各品类月度销售热度指数（0-100），颜色越深表示销售额越高</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex gap-0.5 p-0.5 rounded" style={{ background: '#FAFAF8' }}>
              {[{k:'sales',l:'销量'},{k:'growth',l:'增长'}].map((m) => (
                <button key={m.k} onClick={() => setHeatmapMetric(m.k as any)}
                  className="px-2.5 h-6 rounded text-[10px] font-medium transition-all"
                  style={heatmapMetric === m.k ? { background: '#E8785A', color: '#fff' } : { color: '#A8A29E' }}>{m.l}</button>
              ))}
            </div>
          </div>
        </div>
        <EChartsHeatmap
          xLabels={filteredMonths}
          yLabels={HEATMAP_CATEGORIES}
          data={filteredHeatmapData}
          height={380}
        />
      </div>

      {/* Category Treemap Decomposition */}
      <div className="bg-white rounded-lg shadow-lc p-4 ring-1 ring-[#EDEAE5]/60 mt-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-semibold" style={{ color: '#E8785A' }}>品类树形分解</h3>
          <div className="flex items-center gap-1">
            <Layers size={12} style={{ color: '#E8785A' }} />
            <span className="text-[10px] font-medium" style={{ color: '#A8A29E' }}>销售额 & 涨跌幅</span>
          </div>
        </div>
        <EChartsTreemap height={520} />
      </div>

      {/* GMV Trend + Category Share side by side */}
      <div className="grid grid-cols-2 gap-4 mt-4">
        {/* GMV Trend Line */}
        <div className="bg-white rounded-lg shadow-lc p-4 ring-1 ring-[#EDEAE5]/60">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-semibold" style={{ color: '#E8785A' }}>月度GMV趋势</h3>
            <div className="flex items-center gap-1">
              <Activity size={12} style={{ color: '#E8785A' }} />
              <span className="text-[10px] font-medium" style={{ color: '#A8A29E' }}>单位: 亿美元</span>
            </div>
          </div>
          <EChartsLine
            data={gmvData}
            color={'#E8785A'}
            height={260}
            yAxisName="GMV($B)"
          />
        </div>

        {/* Category Pie */}
        <div className="bg-white rounded-lg shadow-lc p-4 ring-1 ring-[#EDEAE5]/60">
          <h3 className="text-sm font-semibold mb-2" style={{ color: '#E8785A' }}>品类市场份额</h3>
          <EChartsPie
            data={CATEGORY_SHARE.slice(0, 6).map(c => ({ name: c.name, value: c.value }))}
            height={260}
            donut
          />
        </div>
      </div>

      {/* Price Distribution */}
      <div className="bg-white rounded-lg shadow-lc p-4 mt-4 ring-1 ring-[#EDEAE5]/60">
        <h3 className="text-sm font-semibold mb-4" style={{ color: '#E8785A' }}>价格带分布</h3>
        <div className="grid grid-cols-3 gap-4">
          <EChartsBar
            data={PRICE_RANGE_TREND.map(d => ({ label: d.range, value: d.products }))}
            title="商品数量"
            color={'#E8785A'}
            height={220}
          />
          <EChartsBar
            data={PRICE_RANGE_TREND.map(d => ({ label: d.range, value: d.sales }))}
            title="销量"
            color={'#E8785A'}
            height={220}
          />
          <EChartsBar
            data={PRICE_RANGE_TREND.map(d => ({ label: d.range, value: d.revenue }))}
            title="销售额($M)"
            color={'#14B8A6'}
            height={220}
          />
        </div>
      </div>

      {/* Influencer Matrix - Enhanced */}
      <div className="bg-white rounded-lg shadow-lc p-4 mt-4 ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold" style={{ color: '#E8785A' }}>带货达人矩阵</h3>
          <div className="flex items-center gap-1">
            <Users size={12} style={{ color: '#E8785A' }} />
            <span className="text-[10px] font-medium" style={{ color: '#A8A29E' }}>共26.4M达人</span>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr style={{ background: '#FAFAF8' }}>
                  {["粉丝量级", "达人数", "占比", "总销量", "平均GPM"].map(h => (
                    <th key={h} className={`py-2.5 px-3 text-xs font-semibold ${h === '粉丝量级' ? 'text-left' : 'text-right'}`} style={{ color: '#78716C' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {INFLUENCER_MATRIX.map((row) => (
                  <tr key={row.range} className="border-b transition-colors hover:bg-[#F7F8F9] cursor-pointer" style={{ borderColor: '#F5F2EE' }}
                    onClick={() => setActiveCategory(activeCategory === 0 ? null : 0)}>
                    <td className="py-2.5 px-3 font-semibold text-left text-xs" style={{ color: '#E8785A' }}>{row.range}</td>
                    <td className="py-2.5 px-3 text-right text-xs font-mono-num" style={{ color: '#1C1917' }}>{(row.accounts / 1000000).toFixed(1)}M</td>
                    <td className="py-2.5 px-3">
                      <div className="flex items-center justify-end gap-2">
                        <div className="w-14 h-1.5 rounded-full overflow-hidden" style={{ background: '#F5F2EE' }}>
                          <div className="h-full rounded-full" style={{ width: row.accountRatio, background: '#E8785A' }} />
                        </div>
                        <span className="font-mono-num text-[10px]" style={{ color: '#A8A29E' }}>{row.accountRatio}</span>
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-right text-xs font-mono-num font-semibold" style={{ color: '#1C1917' }}>{(row.sales / 1000000).toFixed(0)}M</td>
                    <td className="py-2.5 px-3 text-right text-xs font-mono-num font-semibold" style={{ color: '#E8785A' }}>${row.avgRevenue.toFixed(0)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {/* Horizontal bar chart for influencer distribution */}
          <EChartsBar
            data={INFLUENCER_MATRIX.slice().reverse().map(r => ({
              label: r.range,
              value: r.accounts,
            }))}
            color={'#14B8A6'}
            height={240}
            horizontal
          />
        </div>
      </div>
    </div>
  );
}
