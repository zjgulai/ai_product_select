import { useState } from 'react';
import Breadcrumb from '@/components/shared/Breadcrumb';
import {
  HOME_PRODUCTS_HOT, HOME_PRODUCTS_SOARING, HOME_PRODUCTS_NEW,
  HOME_INFLUENCERS_SALES, HOME_INFLUENCERS_FANS,
  HOME_SHOPS_HOT, HOME_VIDEOS_HOT, HOME_LIVES_POPULAR
} from '@/data/mockData';
import { useBatchDynamicData } from '@/hooks/useBatchDynamicData';
import { ShoppingBag, Users, Store, Play, Video, ChevronRight, Search } from 'lucide-react';

const ENTRIES = [
  { icon: ShoppingBag, title: "找商品", placeholder: "搜索商品", links: ["昨日销量最高的商品", "昨日销量环比最高的商品", "30日内上架销量最高的商品"] },
  { icon: Users, title: "找达人", placeholder: "搜索达人", links: ["近30日带货销售额最多的达人", "近30日粉丝增长数最多的达人"] },
  { icon: Store, title: "找小店", placeholder: "搜索小店", links: ["近7日销量最高的小店", "近7日销量环比增长最多的小店"] },
  { icon: Play, title: "找视频", placeholder: "搜索视频", links: ["近30日发布播放量最高的视频", "近30日发布销量最高的视频"] },
  { icon: Video, title: "找直播", placeholder: "搜索直播", links: ["近30日累计观看人次最多的直播", "近30日涨粉数最高的直播"] },
];

const PRODUCT_IMAGES = [
  "/assets/products/p1.jpg", "/assets/products/p2.jpg", "/assets/products/p3.jpg",
  "/assets/products/p4.jpg", "/assets/products/p5.jpg",
];

const AVATAR_IMAGES = [
  "/assets/avatars/a1.jpg", "/assets/avatars/a2.jpg", "/assets/avatars/a3.jpg",
];

export default function TikTokHome() {
  const [productTab, setProductTab] = useState(0);
  const [influencerTab, setInfluencerTab] = useState(0);
  const [shopTab, setShopTab] = useState(0);
  const [videoTab, setVideoTab] = useState(0);

  const { results: db } = useBatchDynamicData([
    { dataKey: 'tiktok_home_products_hot', mockData: HOME_PRODUCTS_HOT },
    { dataKey: 'tiktok_home_products_soaring', mockData: HOME_PRODUCTS_SOARING },
    { dataKey: 'tiktok_home_products_new', mockData: HOME_PRODUCTS_NEW },
    { dataKey: 'tiktok_home_influencers_sales', mockData: HOME_INFLUENCERS_SALES },
    { dataKey: 'tiktok_home_influencers_fans', mockData: HOME_INFLUENCERS_FANS },
    { dataKey: 'tiktok_home_shops_hot', mockData: HOME_SHOPS_HOT },
    { dataKey: 'tiktok_home_videos_hot', mockData: HOME_VIDEOS_HOT },
    { dataKey: 'tiktok_home_lives_popular', mockData: HOME_LIVES_POPULAR },
  ]);

  const productTabs = ["商品热销榜", "商品飙升榜", "商品新品榜"];
  const productData = [
    db['tiktok_home_products_hot'].records,
    db['tiktok_home_products_soaring'].records,
    db['tiktok_home_products_new'].records,
  ];
  const influencerTabs = ["达人带货榜", "达人涨粉榜"];
  const influencerData = [
    db['tiktok_home_influencers_sales'].records,
    db['tiktok_home_influencers_fans'].records,
  ];

  return (
    <div className="animate-fadeIn">
      <Breadcrumb items={["TikTok趋势", "首页"]} />

      {/* Entry Cards */}
      <div className="bg-white rounded-lg shadow-lc p-4 mb-4">
        <div className="grid grid-cols-5 gap-4">
          {ENTRIES.map((entry, i) => (
            <div key={i} className="bg-[#F7F8F9] rounded-lg p-3 ring-1 ring-[#EDEAE5] hover:shadow-lc-hover hover:-translate-y-0.5 transition-all duration-200">
              <div className="flex items-center gap-2 mb-2.5">
                <div className="w-8 h-8 rounded-md flex items-center justify-center" style={{ backgroundColor: `${'#E8785A'}12` }}>
                  <entry.icon size={17} style={{ color: '#E8785A' }} />
                </div>
                <span className="text-sm font-semibold" style={{ color: '#E8785A' }}>{entry.title}</span>
              </div>
              <div className="relative mb-2">
                <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#A8A29E' }} />
                <input type="text" placeholder={entry.placeholder}
                  className="w-full h-8 pl-8 pr-3 rounded-full border text-xs transition-all focus:outline-none focus:ring-1"
                  style={{ borderColor: '#EDEAE5', color: '#1C1917', background: '#fff' }}
                  onFocus={e => { e.target.style.borderColor = '#E8785A'; }}
                  onBlur={e => e.target.style.borderColor = '#EDEAE5'}
                />
              </div>
              <div className="space-y-1">
                {entry.links.map((link, j) => (
                  <button key={j} className="flex items-center text-[11px] transition-colors w-full group" style={{ color: '#A8A29E' }}
                    onMouseEnter={e => e.currentTarget.style.color = '#E8785A'}
                    onMouseLeave={e => e.currentTarget.style.color = '#A8A29E'}>
                    <ChevronRight size={10} className="transition-transform group-hover:translate-x-0.5" />
                    <span className="truncate">{link}</span>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Product & Influencer Rankings */}
      <div className="grid grid-cols-2 gap-4 mb-4">
        {/* Product Rankings */}
        <div className="bg-white rounded-lg shadow-lc p-4 ring-1 ring-[#EDEAE5]/60">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold" style={{ color: '#E8785A' }}>商品榜单</h3>
            <button className="text-xs font-medium flex items-center gap-0.5 transition-colors" style={{ color: '#E8785A' }}
              onMouseEnter={e => e.currentTarget.style.color = '#D46040'}
              onMouseLeave={e => e.currentTarget.style.color = '#E8785A'}>
              完整榜单 <ChevronRight size={12} />
            </button>
          </div>
          <div className="flex gap-4 border-b mb-3" style={{ borderColor: '#EDEAE5' }}>
            {productTabs.map((tab, i) => (
              <button key={tab} onClick={() => setProductTab(i)}
                className="pb-2 text-xs font-medium transition-all border-b-2"
                style={productTab === i ? { color: '#E8785A', borderColor: '#E8785A' } : { color: '#A8A29E', borderColor: 'transparent' }}>
                {tab}
              </button>
            ))}
          </div>
          <table className="w-full">
            <tbody>
              {productData[productTab].map((item) => (
                <tr key={item.rank} className="border-b last:border-0 transition-colors hover:bg-[#F7F8F9]"
                  style={{ borderColor: '#F5F2EE' }}>
                  <td className="py-2 w-10">
                    <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                      item.rank <= 3 ? "text-white" : "text-[#A8A29E]" }`}
                      style={item.rank <= 3 ? { background: item.rank === 1 ? '#D49450' : item.rank === 2 ? '#D6D3D0' : '#D4A080' } : { background: '#F5F2EE' }}>
                      {item.rank}
                    </span>
                  </td>
                  <td className="py-2">
                    <div className="flex items-center gap-2">
                      <img src={PRODUCT_IMAGES[(item.rank - 1) % PRODUCT_IMAGES.length]} alt="" className="w-8 h-8 rounded object-cover ring-1 ring-[#EDEAE5]" />
                      <div>
                        <div className="text-xs truncate max-w-[160px]" style={{ color: '#1C1917' }} title={item.name}>{item.name}</div>
                        <div className="text-[10px]" style={{ color: '#A8A29E' }}>{item.category}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-2 text-right text-xs font-semibold font-mono-num" style={{ color: '#1C1917' }}>{item.sales}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Influencer Rankings */}
        <div className="bg-white rounded-lg shadow-lc p-4 ring-1 ring-[#EDEAE5]/60">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold" style={{ color: '#E8785A' }}>达人榜单</h3>
            <button className="text-xs font-medium flex items-center gap-0.5" style={{ color: '#E8785A' }}>
              完整榜单 <ChevronRight size={12} />
            </button>
          </div>
          <div className="flex gap-4 border-b mb-3" style={{ borderColor: '#EDEAE5' }}>
            {influencerTabs.map((tab, i) => (
              <button key={tab} onClick={() => setInfluencerTab(i)}
                className="pb-2 text-xs font-medium transition-all border-b-2"
                style={influencerTab === i ? { color: '#E8785A', borderColor: '#E8785A' } : { color: '#A8A29E', borderColor: 'transparent' }}>
                {tab}
              </button>
            ))}
          </div>
          <table className="w-full">
            <tbody>
              {influencerData[influencerTab].map((item) => (
                <tr key={item.rank} className="border-b last:border-0 hover:bg-[#F7F8F9] transition-colors" style={{ borderColor: '#F5F2EE' }}>
                  <td className="py-2 w-10">
                    <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${item.rank <= 3 ? 'text-white' : 'text-[#A8A29E]'}`}
                      style={item.rank <= 3 ? { background: item.rank === 1 ? '#D49450' : item.rank === 2 ? '#D6D3D0' : '#D4A080' } : { background: '#F5F2EE' }}>
                      {item.rank}
                    </span>
                  </td>
                  <td className="py-2">
                    <div className="flex items-center gap-2">
                      <img src={AVATAR_IMAGES[(item.rank - 1) % AVATAR_IMAGES.length]} alt="" className="w-7 h-7 rounded-full object-cover ring-1 ring-[#EDEAE5]" />
                      <span className="text-xs" style={{ color: '#1C1917' }}>{item.username}</span>
                    </div>
                  </td>
                  <td className="py-2 text-right text-xs font-semibold font-mono-num" style={{ color: '#1C1917' }}>{item.sales}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Shop & Video Rankings */}
      <div className="grid grid-cols-2 gap-4 mb-4">
        {/* Shop Rankings */}
        <div className="bg-white rounded-lg shadow-lc p-4 ring-1 ring-[#EDEAE5]/60">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold" style={{ color: '#E8785A' }}>小店榜单</h3>
            <button className="text-xs font-medium flex items-center gap-0.5" style={{ color: '#E8785A' }}>完整榜单 <ChevronRight size={12} /></button>
          </div>
          <div className="flex gap-4 border-b mb-3" style={{ borderColor: '#EDEAE5' }}>
            {["小店热销榜", "小店飙升榜"].map((tab, i) => (
              <button key={tab} onClick={() => setShopTab(i)}
                className="pb-2 text-xs font-medium transition-all border-b-2"
                style={shopTab === i ? { color: '#E8785A', borderColor: '#E8785A' } : { color: '#A8A29E', borderColor: 'transparent' }}>{tab}</button>
            ))}
          </div>
          <table className="w-full">
            <tbody>
              {db['tiktok_home_shops_hot'].records.map((item) => (
                <tr key={item.rank} className="border-b last:border-0 hover:bg-[#F7F8F9] transition-colors" style={{ borderColor: '#F5F2EE' }}>
                  <td className="py-2 w-10">
                    <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${item.rank <= 3 ? 'text-white' : 'text-[#A8A29E]'}`}
                      style={item.rank <= 3 ? { background: item.rank === 1 ? '#D49450' : item.rank === 2 ? '#D6D3D0' : '#D4A080' } : { background: '#F5F2EE' }}>{item.rank}</span>
                  </td>
                  <td className="py-2">
                    <div className="flex items-center gap-2">
                      <img src="/assets/shops/s1.jpg" alt="" className="w-6 h-6 rounded object-cover ring-1 ring-[#EDEAE5]" />
                      <div>
                        <div className="text-xs" style={{ color: '#1C1917' }}>{item.name}</div>
                        <div className="text-[10px]" style={{ color: '#A8A29E' }}>{item.country}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-2 text-right text-xs font-semibold font-mono-num" style={{ color: '#1C1917' }}>{item.sales}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Video Rankings */}
        <div className="bg-white rounded-lg shadow-lc p-4 ring-1 ring-[#EDEAE5]/60">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold" style={{ color: '#E8785A' }}>视频榜单</h3>
            <button className="text-xs font-medium flex items-center gap-0.5" style={{ color: '#E8785A' }}>完整榜单 <ChevronRight size={12} /></button>
          </div>
          <div className="flex gap-4 border-b mb-3" style={{ borderColor: '#EDEAE5' }}>
            {["视频热播榜", "视频热销榜"].map((tab, i) => (
              <button key={tab} onClick={() => setVideoTab(i)}
                className="pb-2 text-xs font-medium transition-all border-b-2"
                style={videoTab === i ? { color: '#E8785A', borderColor: '#E8785A' } : { color: '#A8A29E', borderColor: 'transparent' }}>{tab}</button>
            ))}
          </div>
          <table className="w-full">
            <tbody>
              {db['tiktok_home_videos_hot'].records.map((item) => (
                <tr key={item.rank} className="border-b last:border-0 hover:bg-[#F7F8F9] transition-colors" style={{ borderColor: '#F5F2EE' }}>
                  <td className="py-2 w-10">
                    <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${item.rank <= 3 ? 'text-white' : 'text-[#A8A29E]'}`}
                      style={item.rank <= 3 ? { background: item.rank === 1 ? '#D49450' : item.rank === 2 ? '#D6D3D0' : '#D4A080' } : { background: '#F5F2EE' }}>{item.rank}</span>
                  </td>
                  <td className="py-2">
                    <div className="flex items-center gap-2">
                      <div className="w-10 h-[30px] rounded flex items-center justify-center text-[10px] ring-1 ring-[#EDEAE5] relative overflow-hidden" style={{ background: '#FAFAF8' }}>
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="white"><path d="M8 5v14l11-7z"/></svg>
                        <span className="absolute bottom-0 right-0 text-[7px] px-1 rounded-tl" style={{ background: 'rgba(0,0,0,0.7)', color: '#fff' }}>{item.duration}</span>
                      </div>
                      <div>
                        <div className="text-xs truncate max-w-[140px]" style={{ color: '#1C1917' }} title={item.title}>{item.title}</div>
                        <div className="text-[10px]" style={{ color: '#A8A29E' }}>{item.date}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-2 text-right text-xs font-semibold font-mono-num" style={{ color: '#1C1917' }}>{item.views}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Live Rankings */}
      <div className="bg-white rounded-lg shadow-lc p-4 ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold" style={{ color: '#E8785A' }}>直播榜单</h3>
          <button className="text-xs font-medium flex items-center gap-0.5" style={{ color: '#E8785A' }}>完整榜单 <ChevronRight size={12} /></button>
        </div>
        <div className="flex gap-4 border-b mb-3" style={{ borderColor: '#EDEAE5' }}>
          {["直播人气榜", "直播涨粉榜"].map((tab, i) => (
            <button key={tab} onClick={() => {}} className="pb-2 text-xs font-medium transition-all border-b-2 border-transparent" style={{ color: i === 0 ? '#E8785A' : '#A8A29E', borderColor: i === 0 ? '#E8785A' : 'transparent' }}>{tab}</button>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-6">
          {db['tiktok_home_lives_popular'].records.map((item) => (
            <div key={item.rank} className="flex items-center gap-3 py-2 border-b last:border-0" style={{ borderColor: '#F5F2EE' }}>
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${item.rank <= 3 ? 'text-white' : 'text-[#A8A29E]'}`}
                style={item.rank <= 3 ? { background: item.rank === 1 ? '#D49450' : item.rank === 2 ? '#D6D3D0' : '#D4A080' } : { background: '#F5F2EE' }}>{item.rank}</span>
              <img src="/assets/products/p1.jpg" alt="" className="w-9 h-7 rounded object-cover ring-1 ring-[#EDEAE5]" />
              <div className="flex-1 min-w-0"><div className="text-xs truncate" style={{ color: '#1C1917' }}>{item.title}</div></div>
              <div className="text-xs font-semibold font-mono-num shrink-0" style={{ color: '#1C1917' }}>{item.viewers}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="bg-white rounded-lg shadow-lc p-6 mt-4 ring-1 ring-[#EDEAE5]/60">
        <div className="flex justify-between items-start">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <div className="w-6 h-6 rounded flex items-center justify-center" style={{ background: '#E8785A' }}>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M3 3h7v7H3V3zm11 0h7v4h-7V3zM3 14h4v7H3v-4zm7-4h11v4H10v-4zm0 7h7v4h-7v-4z" fill="'#14B8A6'"/></svg>
              </div>
              <span className="text-sm font-semibold" style={{ color: '#E8785A' }}>路特 AI</span>
            </div>
            <p className="text-xs" style={{ color: '#A8A29E' }}>跨境增长AI大数据解决方案，就选路特</p>
          </div>
          <div className="text-right">
            <p className="text-xs" style={{ color: '#A8A29E' }}>© 路特创新</p>
            <p className="text-xs" style={{ color: '#E0DCD6' }}>浙ICP备2022015040号</p>
          </div>
        </div>
      </div>
    </div>
  );
}
