import { useState } from 'react';
import Breadcrumb from '@/components/shared/Breadcrumb';
import MiniTrend from '@/components/shared/MiniTrend';

import { Download } from 'lucide-react';

const BRAND_DATA = [
  { rank: 1, keyword: "air fryer", trend: [55,58,62,65,68,72,75,78,82,85], sales: 985600, salesG: "+8.2%", revenue: 23654400, revG: "+6.5%", price: 24.0, rating: 4.4, top3: "32.1%", newP: "2.8%", brands: "Ninja,COSORI,Instant" },
  { rank: 2, keyword: "water bottle", trend: [48,52,55,58,60,62,65,68,70,72], sales: 856200, salesG: "+6.8%", revenue: 11986800, revG: "+5.2%", price: 14.0, rating: 4.5, top3: "28.4%", newP: "3.5%", brands: "Hydro Flask,Takeya,CamelBak" },
  { rank: 3, keyword: "bananas", trend: [42,45,48,50,52,55,58,60,62,65], sales: 756800, salesG: "+4.5%", revenue: 4540800, revG: "+3.1%", price: 6.0, rating: 4.7, top3: "45.2%", newP: "0.5%", brands: "Dole,Chiquita,Del Monte" },
  { rank: 4, keyword: "toilet paper", trend: [65,62,60,58,55,52,50,48,52,55], sales: 1256800, salesG: "-2.1%", revenue: 15081600, revG: "-1.8%", price: 12.0, rating: 4.6, top3: "52.8%", newP: "0.2%", brands: "Charmin,Cottonelle,Angel Soft" },
  { rank: 5, keyword: "shower curtain", trend: [35,38,42,45,48,50,48,45,42,40], sales: 425600, salesG: "+3.2%", revenue: 5107200, revG: "+2.8%", price: 12.0, rating: 4.2, top3: "18.5%", newP: "4.2%", brands: "LiBa,Utopia,AmazerBath" },
];

export default function BrandTrend() {
  const [searchText, setSearchText] = useState("");
  const filtered = searchText ? BRAND_DATA.filter(d => d.keyword.includes(searchText.toLowerCase())) : BRAND_DATA;

  return (
    <div className="animate-fadeIn">
      <Breadcrumb items={["Amazon趋势", "品牌趋势"]} />
      <div className="bg-white rounded-lg shadow-lc p-4 mb-4 ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-base font-bold" style={{ color: '#1C1917' }}>品牌趋势</h2>
            <p className="text-[11px] mt-0.5" style={{ color: '#A8A29E' }}>含品牌词的搜索词，且增长的市场 · 共 12,838 个</p>
          </div>
          <div className="flex items-center gap-0">
            <input type="text" value={searchText} onChange={e => setSearchText(e.target.value)} placeholder="搜索关键词..." className="w-64 h-9 pl-4 pr-3 rounded-l-full border border-r-0 text-xs" style={{ borderColor: '#EDEAE5' }} />
            <button className="h-9 px-5 rounded-r-full text-xs font-bold" style={{ background: '#E8785A', color: '#1C1917' }}>搜索</button>
          </div>
        </div>
      </div>
      <div className="bg-white rounded-lg shadow-lc overflow-hidden ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center justify-between p-3 border-b" style={{ borderColor: '#EDEAE5' }}>
          <h3 className="text-sm font-bold" style={{ color: '#1C1917' }}>品牌趋势排名</h3>
          <button className="flex items-center gap-1 text-xs font-bold" style={{ color: '#E8785A' }}><Download size={12} /> 导出</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ background: '#FAFAF8' }}>
                {['排名','关键词','趋势','月销量','月销售额($)','均价','评分','TOP3','新品','主要品牌'].map(h => (
                  <th key={h} className="py-2.5 px-3 text-[11px] font-bold" style={{ color: '#78716C' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((item, idx) => (
                <tr key={idx} className="border-b hover:bg-[#FAFAF8]" style={{ borderColor: '#F5F2EE' }}>
                  <td className="py-2.5 px-3"><span className="text-xs font-bold font-mono-num" style={{ color: idx < 3 ? '#E8785A' : '#A8A29E', background: idx < 3 ? '#FEF2EE' : 'transparent', width: 22, height: 22, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', borderRadius: 6 }}>{item.rank}</span></td>
                  <td className="py-2.5 px-3 text-xs font-bold" style={{ color: '#E8785A' }}>{item.keyword}</td>
                  <td className="py-2.5 px-3"><MiniTrend data={item.trend} /></td>
                  <td className="py-2.5 px-3 text-right"><div className="text-xs font-bold font-mono-num">{item.sales.toLocaleString()}</div><div className="text-[10px] font-bold" style={{ color: item.salesG.startsWith('+') ? '#16A34A' : '#DC2626' }}>{item.salesG}</div></td>
                  <td className="py-2.5 px-3 text-right text-xs font-bold font-mono-num" style={{ color: '#E8785A' }}>${item.revenue.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num">${item.price}</td>
                  <td className="py-2.5 px-3 text-right"><span className="text-xs font-bold" style={{ color: item.rating >= 4.5 ? '#16A34A' : '#14B8A6' }}>{item.rating}</span></td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num">{item.top3}</td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num" style={{ color: '#16A34A' }}>{item.newP}</td>
                  <td className="py-2.5 px-3"><div className="flex flex-wrap gap-1">{item.brands.split(',').map(b => <span key={b} className="text-[9px] px-1.5 py-0.5 rounded font-medium bg-gray-100" style={{ background: '#DBEAFE', color: '#E8785A' }}>{b}</span>)}</div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
