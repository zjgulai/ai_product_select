import { useState } from 'react';
import Breadcrumb from '@/components/shared/Breadcrumb';

import { User, FileText, Package, Link2, Settings, Download, Crown } from 'lucide-react';

const TABS = [
  { key: 'overview', label: '账号总览', icon: User },
  { key: 'orders', label: '订购记录', icon: Package },
  { key: 'reports', label: '报告记录', icon: FileText },
  { key: 'params', label: '参数库', icon: Settings },
  { key: 'links', label: '推广链接', icon: Link2 },
];

const REPORT_HISTORY = [
  { name: "momcozy baby bottle warmer 产品分析", date: "2026-04-20", status: "已完成", type: "产品分析" },
  { name: "air fryer 关键词趋势报告", date: "2026-04-18", status: "已完成", type: "关键词趋势" },
  { name: "vacuum cleaner 竞品分析", date: "2026-04-15", status: "已完成", type: "竞品分析" },
  { name: "women tshirts 市场洞察", date: "2026-04-10", status: "已完成", type: "市场洞察" },
  { name: "camping chairs 季节性分析", date: "2026-04-05", status: "生成中", type: "季节性分析" },
];

const ORDERS = [
  { plan: "高级版年付", price: "¥2,999", date: "2025-04-22", status: "生效中", expire: "2026-04-22" },
  { plan: "专业版月付", price: "¥399", date: "2025-03-22", status: "已过期", expire: "2025-04-22" },
];

export default function UserCenter() {
  const [tab, setTab] = useState('overview');

  return (
    <div className="animate-fadeIn">
      <Breadcrumb items={["用户中心"]} />

      {/* User Header */}
      <div className="rounded-xl p-5 mb-4 ring-1 ring-[#EDEAE5]/60" style={{ background: 'linear-gradient(135deg, #E8785A 0%, #D46040 100%)' }}>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full flex items-center justify-center" style={{ background: '#E8785A' }}>
            <User size={24} style={{ color: '#1C1917' }} />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h2 className="text-lg font-bold" style={{ color: '#FFFFFF' }}>13680382537</h2>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: '#E8785A', color: '#1C1917' }}>高级版</span>
            </div>
            <p className="text-xs" style={{ color: 'rgba(255,255,255,0.6)' }}>套餐到期: 2026-04-22 | 剩余 365 天</p>
          </div>
          <button className="px-4 h-8 rounded-full text-xs font-bold transition-all hover:brightness-110" style={{ background: '#E8785A', color: '#1C1917' }}>
            <Crown size={12} className="inline mr-1" />续费会员
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-t-lg shadow-lc border-b px-4 pt-3 ring-1 ring-[#EDEAE5]/60">
        <div className="flex gap-5">
          {TABS.map(t => (
            <button key={t.key} onClick={() => setTab(t.key)}
              className="pb-2.5 text-xs font-medium transition-all border-b-2 flex items-center gap-1.5"
              style={tab === t.key ? { color: '#1C1917', borderColor: '#E8785A' } : { color: '#A8A29E', borderColor: 'transparent' }}>
              <t.icon size={13} />{t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="bg-white rounded-b-lg shadow-lc p-5 ring-1 ring-[#EDEAE5]/60">
        {tab === 'overview' && (
          <div className="grid grid-cols-4 gap-4">
            {[
              { label: '剩余天数', value: '365', unit: '天', color: '#E8785A' },
              { label: '已生成报告', value: '42', unit: '份', color: '#E8785A' },
              { label: '关注商品', value: '128', unit: '个', color: '#16A34A' },
              { label: '关注达人', value: '56', unit: '个', color: '#E8810A' },
            ].map(s => (
              <div key={s.label} className="rounded-xl p-4 ring-1 ring-[#EDEAE5]/40" style={{ background: '#FAFAF8' }}>
                <div className="text-[11px] font-medium mb-2" style={{ color: '#A8A29E' }}>{s.label}</div>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-bold font-mono-num" style={{ color: s.color }}>{s.value}</span>
                  <span className="text-[10px]" style={{ color: '#D6D3D0' }}>{s.unit}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === 'orders' && (
          <table className="w-full">
            <thead>
              <tr style={{ background: '#FAFAF8' }}>
                {['套餐','金额','开通日期','状态','到期日','操作'].map(h => <th key={h} className="py-2.5 px-3 text-xs font-semibold text-left" style={{ color: '#78716C' }}>{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {ORDERS.map((o, i) => (
                <tr key={i} className="border-b" style={{ borderColor: '#F5F2EE' }}>
                  <td className="py-3 px-3 text-xs font-semibold" style={{ color: '#1C1917' }}>{o.plan}</td>
                  <td className="py-3 px-3 text-xs font-mono-num font-bold" style={{ color: '#E8785A' }}>{o.price}</td>
                  <td className="py-3 px-3 text-xs" style={{ color: '#A8A29E' }}>{o.date}</td>
                  <td className="py-3 px-3"><span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: o.status === '生效中' ? '#DCFCE7' : '#FEE2E2', color: o.status === '生效中' ? '#16A34A' : '#DC2626' }}>{o.status}</span></td>
                  <td className="py-3 px-3 text-xs" style={{ color: '#A8A29E' }}>{o.expire}</td>
                  <td className="py-3 px-3"><button className="text-[10px] font-bold" style={{ color: '#E8785A', background: '#FFFFFF', padding: '3px 10px', borderRadius: 6 }}>续费</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {tab === 'reports' && (
          <table className="w-full">
            <thead>
              <tr style={{ background: '#FAFAF8' }}>
                {['报告名称','类型','创建日期','状态','操作'].map(h => <th key={h} className="py-2.5 px-3 text-xs font-semibold text-left" style={{ color: '#78716C' }}>{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {REPORT_HISTORY.map((r, i) => (
                <tr key={i} className="border-b hover:bg-[#FAFAF8] transition-colors" style={{ borderColor: '#F5F2EE' }}>
                  <td className="py-2.5 px-3 text-xs font-medium" style={{ color: '#1C1917' }}>{r.name}</td>
                  <td className="py-2.5 px-3"><span className="text-[10px] px-2 py-0.5 rounded-full font-medium" style={{ background: '#DBEAFE', color: '#E8785A' }}>{r.type}</span></td>
                  <td className="py-2.5 px-3 text-xs" style={{ color: '#A8A29E' }}>{r.date}</td>
                  <td className="py-2.5 px-3"><span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: r.status === '已完成' ? '#DCFCE7' : '#FEF3C7', color: r.status === '已完成' ? '#16A34A' : '#E8810A' }}>{r.status}</span></td>
                  <td className="py-2.5 px-3"><button className="text-[10px] font-bold flex items-center gap-1" style={{ color: '#E8785A' }}><Download size={10} /> 下载</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {tab === 'params' && (
          <div className="flex flex-col items-center justify-center py-16">
            <Settings size={36} style={{ color: '#EDEAE5' }} />
            <p className="text-sm font-medium mt-3" style={{ color: '#D6D3D0' }}>暂无自定义参数</p>
            <p className="text-xs mt-1" style={{ color: '#D6D3D0' }}>创建报告时可保存自定义筛选参数</p>
          </div>
        )}

        {tab === 'links' && (
          <div className="flex flex-col items-center justify-center py-16">
            <Link2 size={36} style={{ color: '#EDEAE5' }} />
            <p className="text-sm font-medium mt-3" style={{ color: '#D6D3D0' }}>暂无推广链接</p>
            <p className="text-xs mt-1" style={{ color: '#D6D3D0' }}>邀请好友获取奖励</p>
          </div>
        )}
      </div>
    </div>
  );
}
