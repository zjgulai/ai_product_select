import { useState } from 'react';
import Breadcrumb from '@/components/shared/Breadcrumb';
import MiniTrend from '@/components/shared/MiniTrend';
import { AMAZON_PRODUCTS } from '@/data/mockData';
import { Search, Download, Star, BarChart3, ShoppingCart, X } from 'lucide-react';

const PRODUCT_IMAGES = ["/assets/products/p6.jpg","/assets/products/p5.jpg","/assets/products/p1.jpg","/assets/products/p2.jpg","/assets/products/p3.jpg"];

export default function AmazonProduct() {
  const [tags, setTags] = useState<string[]>(["momcozy ba..."]);
  const removeTag = (tag: string) => setTags(tags.filter(t => t !== tag));

  return (
    <div className="animate-fadeIn">
      <Breadcrumb items={["商品榜单"]} />
      <div className="bg-white rounded-lg shadow-lc p-3 mb-3 ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center gap-2">
          <div className="relative flex-1 max-w-[400px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#A8A29E' }} />
            <input type="text" placeholder="请输入商品名称" className="w-full h-9 pl-9 pr-3 rounded-l-full border border-r-0 text-xs focus:outline-none" style={{ borderColor: '#EDEAE5', color: '#1C1917' }} />
          </div>
          <button className="h-9 px-6 text-white text-xs font-medium rounded-r-full" style={{ background: '#E8785A' }}>搜索</button>
          <button className="h-9 px-3 text-xs font-medium ml-2" style={{ color: '#E8785A' }}>高级搜索</button>
        </div>
      </div>
      <div className="bg-white p-3 border-b ring-1 ring-[#EDEAE5]/60" style={{ borderColor: '#EDEAE5' }}>
        <div className="flex items-center gap-3 flex-wrap">
          {tags.map(tag => (
            <span key={tag} className="flex items-center gap-1 text-xs px-2 py-1 rounded-full font-medium" style={{ background: `${'#E8785A'}10`, color: '#E8785A' }}>
              {tag}<button onClick={() => removeTag(tag)}><X size={10} /></button>
            </span>
          ))}
          <select className="h-7 border rounded text-xs px-2 font-medium" style={{ borderColor: '#EDEAE5', color: '#78716C' }}><option>商品类目</option></select>
          <input type="text" defaultValue="202603" className="w-24 h-7 border rounded px-2 text-xs font-mono-num" style={{ borderColor: '#EDEAE5', color: '#1C1917' }} />
          <span className="text-xs font-medium" style={{ color: '#78716C' }}>上架时间:</span>
          <input type="date" className="h-7 border rounded text-xs px-2" style={{ borderColor: '#EDEAE5' }} />
          <span className="text-xs" style={{ color: '#E0DCD6' }}>-</span>
          <input type="date" className="h-7 border rounded text-xs px-2" style={{ borderColor: '#EDEAE5' }} />
          <span className="text-xs font-medium" style={{ color: '#78716C' }}>销量:</span>
          <input type="text" placeholder="最小值" className="w-20 h-7 border rounded px-2 text-xs" style={{ borderColor: '#EDEAE5', color: '#1C1917' }} />
          <span className="text-xs" style={{ color: '#E0DCD6' }}>-</span>
          <input type="text" placeholder="最大值" className="w-20 h-7 border rounded px-2 text-xs" style={{ borderColor: '#EDEAE5', color: '#1C1917' }} />
          <span className="text-xs font-medium" style={{ color: '#78716C' }}>价格($):</span>
          <input type="text" placeholder="最小值" className="w-20 h-7 border rounded px-2 text-xs" style={{ borderColor: '#EDEAE5', color: '#1C1917' }} />
          <span className="text-xs" style={{ color: '#E0DCD6' }}>-</span>
          <input type="text" placeholder="最大值" className="w-20 h-7 border rounded px-2 text-xs" style={{ borderColor: '#EDEAE5', color: '#1C1917' }} />
          <select className="h-7 border rounded text-xs px-2 font-medium" style={{ borderColor: '#EDEAE5', color: '#78716C' }}><option>默认: 总销量从高到低</option></select>
          <div className="flex gap-2 ml-auto">
            <button className="h-7 px-5 text-white text-xs font-medium rounded-md" style={{ background: '#E8785A' }}>查询</button>
            <button className="h-7 px-5 text-xs font-medium rounded-md border" style={{ color: '#78716C', borderColor: '#EDEAE5' }}>重置</button>
          </div>
        </div>
      </div>
      <div className="bg-white rounded-b-lg shadow-lc overflow-hidden ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center justify-between p-3 border-b" style={{ borderColor: '#EDEAE5' }}>
          <h3 className="text-sm font-semibold" style={{ color: '#E8785A' }}>商品信息</h3>
          <button className="flex items-center gap-1 text-xs font-medium" style={{ color: '#E8785A' }}><Download size={12} /> 数据导出</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ background: '#FAFAF8' }}>
                {["商品图片","商品名称","月销量","月销售额($)","销量趋势","价格($)","ASIN","类目树","品牌","上架时间","1688货源","操作"].map((h, i) => (
                  <th key={h} className={`py-2.5 px-3 text-xs font-semibold ${i===0?'text-left w-[60px]':i===1?'text-left':i===4?'text-center w-[120px]':i===11?'text-center w-[80px]':'text-right'}`}
                    style={{ color: '#78716C' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {AMAZON_PRODUCTS.map((item, idx) => (
                <tr key={idx} className="border-b hover:bg-[#F7F8F9] transition-colors" style={{ borderColor: '#F5F2EE' }}>
                  <td className="py-2.5 px-3"><img src={PRODUCT_IMAGES[idx % PRODUCT_IMAGES.length]} alt="" className="w-9 h-9 rounded object-cover ring-1 ring-[#EDEAE5]" /></td>
                  <td className="py-2.5 px-3"><div className="text-xs truncate max-w-[180px] font-medium" style={{ color: '#1C1917' }} title={item.name}>{item.name}</div></td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num font-semibold" style={{ color: '#1C1917' }}>{item.monthlySales}</td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num font-medium" style={{ color: '#E8785A' }}>{item.monthlyRevenue}</td>
                  <td className="py-2.5 px-3"><div className="flex justify-center"><MiniTrend data={item.salesTrend} /></div></td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num font-semibold" style={{ color: '#1C1917' }}>{item.price}</td>
                  <td className="py-2.5 px-3 text-xs font-mono-num font-medium" style={{ color: '#E8785A' }}>{item.asin}</td>
                  <td className="py-2.5 px-3 text-xs truncate max-w-[200px]" style={{ color: '#A8A29E' }}>{item.category}</td>
                  <td className="py-2.5 px-3 text-xs font-medium" style={{ color: '#1C1917' }}>{item.brand}</td>
                  <td className="py-2.5 px-3 text-xs font-mono-num" style={{ color: '#A8A29E' }}>{item.date}</td>
                  <td className="py-2.5 px-3"><span className="text-xs font-medium cursor-pointer" style={{ color: '#E8785A' }}>{item.source}</span></td>
                  <td className="py-2.5 px-3">
                    <div className="flex items-center justify-center gap-1">
                      {[Star, BarChart3, ShoppingCart].map((Icon, ii) => (
                        <button key={ii} className="transition-colors" style={{ color: '#E0DCD6' }} onMouseEnter={e => e.currentTarget.style.color = '#E8785A'} onMouseLeave={e => e.currentTarget.style.color = '#E0DCD6'}><Icon size={12} /></button>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
