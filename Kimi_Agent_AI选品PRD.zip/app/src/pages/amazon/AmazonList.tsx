import { useState } from 'react';
import Breadcrumb from '@/components/shared/Breadcrumb';
import CategoryFilter from '@/components/shared/CategoryFilter';
import MiniTrend from '@/components/shared/MiniTrend';
import { AMAZON_LIST } from '@/data/mockData';
import { Download, Star, BarChart3, ShoppingCart, Settings } from 'lucide-react';

const TABS = ["商品热销榜", "商品飙升榜", "商品新品榜"];
const PRODUCT_IMAGES = ["/assets/products/p5.jpg","/assets/products/p1.jpg","/assets/products/p2.jpg","/assets/products/p3.jpg","/assets/products/p4.jpg"];

export default function AmazonListPage() {
  const [tab, setTab] = useState(0);

  return (
    <div className="animate-fadeIn">
      <Breadcrumb items={["Amazon榜单"]} />
      <div className="bg-white rounded-t-lg shadow-lc border-b px-4 pt-3 ring-1 ring-[#EDEAE5]/60">
        <div className="flex gap-6">
          {TABS.map((t, i) => (
            <button key={t} onClick={() => setTab(i)} className="pb-2.5 text-xs font-medium transition-all border-b-2"
              style={tab === i ? { color: '#E8785A', borderColor: '#E8785A' } : { color: '#A8A29E', borderColor: 'transparent' }}>{t}</button>
          ))}
        </div>
      </div>
      <CategoryFilter />
      <div className="bg-white rounded-b-lg shadow-lc overflow-hidden ring-1 ring-[#EDEAE5]/60">
        <div className="flex items-center justify-between p-3 border-b" style={{ borderColor: '#EDEAE5' }}>
          <h3 className="text-sm font-semibold" style={{ color: '#E8785A' }}>商品信息</h3>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-1 text-xs font-medium" style={{ color: '#E8785A' }}><Download size={12} /> 数据导出</button>
            <button className="transition-colors" style={{ color: '#A8A29E' }}><Settings size={14} /></button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ background: '#FAFAF8' }}>
                {["排名","商品图片","商品名称","月销量","月销售额($)","销量趋势","价格($)","价格趋势","ASIN","类目树","品牌","上架时间","操作"].map((h, i) => (
                  <th key={h} className={`py-2.5 px-3 text-xs font-semibold ${i===0?'text-left w-[50px]':i===1?'text-left w-[60px]':i===2?'text-left':i===5||i===7?'text-center w-[120px]':i===12?'text-center w-[80px]':'text-right'}`}
                    style={{ color: '#78716C' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {AMAZON_LIST.map((item, idx) => (
                <tr key={idx} className="border-b hover:bg-[#F7F8F9] transition-colors" style={{ borderColor: '#F5F2EE' }}>
                  <td className="py-2.5 px-3 text-xs font-mono-num font-semibold" style={{ color: '#A8A29E' }}>{item.rank}</td>
                  <td className="py-2.5 px-3"><img src={PRODUCT_IMAGES[idx % PRODUCT_IMAGES.length]} alt="" className="w-9 h-9 rounded object-cover ring-1 ring-[#EDEAE5]" /></td>
                  <td className="py-2.5 px-3"><div className="text-xs truncate max-w-[200px] font-medium" style={{ color: '#1C1917' }} title={item.name}>{item.name}</div></td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num font-semibold" style={{ color: '#1C1917' }}>{item.monthlySales.toLocaleString()}</td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num font-medium" style={{ color: '#E8785A' }}>{item.monthlyRevenue.toLocaleString()}</td>
                  <td className="py-2.5 px-3"><div className="flex justify-center"><MiniTrend data={item.salesTrend} /></div></td>
                  <td className="py-2.5 px-3 text-right text-xs font-mono-num font-semibold" style={{ color: '#1C1917' }}>{item.price}</td>
                  <td className="py-2.5 px-3"><div className="flex justify-center"><MiniTrend data={item.priceTrend} color="#FF9500" /></div></td>
                  <td className="py-2.5 px-3 text-xs font-mono-num font-medium" style={{ color: '#E8785A' }}>{item.asin}</td>
                  <td className="py-2.5 px-3 text-xs truncate max-w-[120px]" style={{ color: '#A8A29E' }}>{item.category}</td>
                  <td className="py-2.5 px-3 text-xs font-medium" style={{ color: '#1C1917' }}>{item.brand}</td>
                  <td className="py-2.5 px-3 text-xs font-mono-num" style={{ color: '#A8A29E' }}>{item.date}</td>
                  <td className="py-2.5 px-3">
                    <div className="flex items-center justify-center gap-1">
                      {[Star, BarChart3, ShoppingCart].map((Icon, ii) => (
                        <button key={ii} className="transition-colors" style={{ color: '#E0DCD6' }} onMouseEnter={e => e.currentTarget.style.color = '#E8785A'} onMouseLeave={e => e.currentTarget.style.color = '#E0DCD6'}><Icon size={12} /></button>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
