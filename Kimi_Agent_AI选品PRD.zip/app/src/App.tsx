import { HashRouter, Routes, Route } from 'react-router';
import AppLayout from '@/components/layout/AppLayout';
import TikTokHome from '@/pages/tiktok/Home';
import TikTokAnalysis from '@/pages/tiktok/Analysis';
import TikTokProducts from '@/pages/tiktok/Products';
import TikTokInfluencer from '@/pages/tiktok/Influencer';
import TikTokShop from '@/pages/tiktok/Shop';
import TikTokVideo from '@/pages/tiktok/Video';
import TikTokLive from '@/pages/tiktok/Live';
import TikTokAttention from '@/pages/tiktok/Attention';
import AmazonKeyword from '@/pages/amazon/Keyword';
import AmazonListPage from '@/pages/amazon/AmazonList';
import AmazonProduct from '@/pages/amazon/Product';
import ParamTrend from '@/pages/amazon/ParamTrend';
import BrandTrend from '@/pages/amazon/BrandTrend';
import HotMarket from '@/pages/amazon/HotMarket';
import PotMarket from '@/pages/amazon/PotMarket';
import ReportAnalysis from '@/pages/report/Analysis';
import UserCenter from '@/pages/user/UserCenter';
import DataManager from '@/pages/data/DataManager';

function App() {
  return (
    <HashRouter>
      <Routes>
        <Route element={<AppLayout />}>
          <Route path="/" element={<TikTokHome />} />
          <Route path="/tiktok/home" element={<TikTokHome />} />
          <Route path="/tiktok/analysis" element={<TikTokAnalysis />} />
          <Route path="/tiktok/products" element={<TikTokProducts />} />
          <Route path="/tiktok/influencer" element={<TikTokInfluencer />} />
          <Route path="/tiktok/shop" element={<TikTokShop />} />
          <Route path="/tiktok/video" element={<TikTokVideo />} />
          <Route path="/tiktok/live" element={<TikTokLive />} />
          <Route path="/tiktok/attention" element={<TikTokAttention />} />
          <Route path="/amazon/keyword" element={<AmazonKeyword />} />
          <Route path="/amazon/list" element={<AmazonListPage />} />
          <Route path="/amazon/product" element={<AmazonProduct />} />
          <Route path="/amazon/param-trend" element={<ParamTrend />} />
          <Route path="/amazon/brand-trend" element={<BrandTrend />} />
          <Route path="/amazon/hot-market" element={<HotMarket />} />
          <Route path="/amazon/pot-market" element={<PotMarket />} />
          <Route path="/report/analysis" element={<ReportAnalysis />} />
          <Route path="/user/center" element={<UserCenter />} />
          <Route path="/data/manager" element={<DataManager />} />
        </Route>
      </Routes>
    </HashRouter>
  );
}

export default App;
