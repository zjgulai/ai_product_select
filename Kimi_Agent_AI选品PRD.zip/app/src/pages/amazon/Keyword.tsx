import { useState } from 'react';
import { useNavigate } from 'react-router';
import Breadcrumb from '@/components/shared/Breadcrumb';
import MiniTrend from '@/components/shared/MiniTrend';
import { KEYWORD_STATS, EXAMPLE_REPORTS, KEYWORD_SEARCH_RESULTS } from '@/data/mockData';
import { LC } from '@/lib/lute-colors';
import { ChevronRight, ArrowRight } from 'lucide-react';

const PRODUCT_IMAGES = ["/assets/products/p1.jpg", "/assets/products/p2.jpg", "/assets/products/p3.jpg",
  "/assets/products/p4.jpg", "/assets/products/p5.jpg", "/assets/products/p6.jpg"];

const STAT_LINKS: Record<string, string> = {
  "参数趋势": "/amazon/param-trend",
  "品牌趋势": "/amazon/brand-trend",
  "热门市场": "/amazon/hot-market",
  "潜力市场": "/amazon/pot-market",
};

export default function AmazonKeyword() {
  const navigate = useNavigate();
  const [searchText, setSearchText] = useState("");
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = () => { if (searchText.trim()) setHasSearched(true); };

  return (
    <div className="animate-fadeIn">
      <Breadcrumb items={["Amazon趋势", "关键词趋势"]} />

      {/* Search Section */}
      <div className="bg-white rounded-lg shadow-lc p-6 mb-4 ring-1 ring-[#EDEAE5]/60 text-center">
        <h2 className="text-xl font-bold mb-1" style={{ color: '#E8785A' }}>产品创新加速器，亿级卖家都在用</h2>
        <p className="text-xs mb-5" style={{ color: '#A8A29E' }}>自定义产品属性分析，细分市场趋势智能捕获，AI评价一键获取</p>
        <div className="flex items-center justify-center gap-0 max-w-[600px] mx-auto">
          <div className="flex items-center gap-1.5 px-3 h-10 border border-r-0 rounded-l-lg bg-white" style={{ borderColor: '#EDEAE5' }}>
            <span className="text-base"><span className="text-xs">US</span></span>
            <span className="text-xs font-medium" style={{ color: '#78716C' }}>美国</span>
            <ChevronRight size={12} style={{ color: '#E0DCD6' }} className="rotate-90" />
          </div>
          <input type="text" value={searchText} onChange={e => setSearchText(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSearch()}
            placeholder="请输入关键词" className="flex-1 h-10 px-4 border border-r-0 text-sm transition-all focus:outline-none" style={{ borderColor: '#EDEAE5', color: '#1C1917' }} />
          <button onClick={handleSearch} className="h-10 px-6 text-white text-sm font-medium rounded-r-lg transition-all hover:brightness-110"
            style={{ background: '#E8785A' }}>搜索</button>
        </div>
        {hasSearched && searchText && (
          <div className="flex items-center gap-2 mt-3 justify-center">
            <span className="text-xs" style={{ color: '#A8A29E' }}>已选关键词:</span>
            <span className="text-xs px-3 py-0.5 rounded-full font-medium" style={{ background: `${'#E8785A'}10`, color: '#E8785A' }}>{searchText}</span>
          </div>
        )}
      </div>

      {/* Stats Cards - Clickable */}
      {!hasSearched && (
        <div className="grid grid-cols-4 gap-4 mb-4">
          {KEYWORD_STATS.map((stat) => (
            <div key={stat.title}
              onClick={() => { const link = STAT_LINKS[stat.title]; if (link) navigate(link); }}
              className="bg-white rounded-lg shadow-lc p-4 transition-all duration-200 hover:-translate-y-1 hover:shadow-lc-hover cursor-pointer group ring-1 ring-[#EDEAE5]/40 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-16 h-16 rounded-full opacity-5 group-hover:opacity-10 transition-opacity" style={{ background: '#E8785A', transform: 'translate(30%, -30%)' }} />
              <h4 className="text-sm font-bold mb-0.5" style={{ color: '#1C1917' }}>{stat.title}</h4>
              <p className="text-[11px] mb-3" style={{ color: '#A8A29E' }}>{stat.desc}</p>
              <div className="flex items-center justify-between">
                <span className="text-xl font-bold font-mono-num" style={{ color: '#E8785A', textShadow: '0 0 8px rgba(204,255,0,0.3)' }}>{stat.value}</span>
                <ArrowRight size={16} className="transition-all group-hover:translate-x-1" style={{ color: '#A8A29E' }} />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Example Reports */}
      {!hasSearched && (
        <div className="bg-white rounded-lg shadow-lc p-4 ring-1 ring-[#EDEAE5]/60">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold" style={{ color: '#E8785A' }}>查看示例报告</h3>
            <span className="text-xs" style={{ color: '#A8A29E' }}>以下为各类目示例报告</span>
          </div>
          <div className="grid grid-cols-4 gap-4">
            {EXAMPLE_REPORTS.map((report, ri) => (
              <div key={report.keyword} className="border rounded-lg p-3 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lc-hover cursor-pointer group"
                style={{ borderColor: '#EDEAE5' }}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] px-1.5 py-0.5 rounded-sm font-medium" style={{ background: '#E8785A', color: '#fff' }}>示例</span>
                </div>
                <h4 className="text-sm font-semibold mb-2" style={{ color: '#E8785A' }}>{report.keyword}</h4>
                <img src={PRODUCT_IMAGES[ri % PRODUCT_IMAGES.length]} alt="" className="w-14 h-14 rounded object-cover mb-2 ring-1 ring-[#EDEAE5]" />
                <div className="text-[11px] font-mono-num" style={{ color: '#A8A29E' }}>商品数量: {report.productCount}</div>
                <div className="text-[11px]" style={{ color: '#A8A29E' }}>报告日期: {report.date}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Search Results */}
      {hasSearched && (
        <div className="bg-white rounded-lg shadow-lc overflow-hidden ring-1 ring-[#EDEAE5]/60">
          <div className="p-4 border-b" style={{ borderColor: '#EDEAE5' }}>
            <h3 className="text-sm font-semibold" style={{ color: '#E8785A' }}>搜索结果</h3>
            <p className="text-xs mt-0.5" style={{ color: '#A8A29E' }}>以下为关键词搜索结果列表</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr style={{ background: '#FAFAF8' }}>
                  {["排名", "关键词", "亚马逊搜索趋势", "月销量", "月销售额($)", "平均价格($)", "评分", "top3销量占比", "新品销量占比", "操作"].map((h, i) => (
                    <th key={h} className={`py-2.5 px-3 text-xs font-semibold ${i===0?'text-left w-[60px]':i===1?'text-left w-[200px]':i===2?'text-center w-[150px]':'text-right'}`}
                      style={{ color: '#78716C' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {KEYWORD_SEARCH_RESULTS.map((item, idx) => (
                  <tr key={idx} className="border-b hover:bg-[#F7F8F9] transition-colors" style={{ borderColor: '#F5F2EE' }}>
                    <td className="py-2.5 px-3 text-xs font-mono-num" style={{ color: '#A8A29E' }}>{item.rank}</td>
                    <td className="py-2.5 px-3">
                      <div className="text-xs font-semibold" style={{ color: '#E8785A' }}>{item.keyword}</div>
                      <button className="text-[10px] font-medium" style={{ color: '#14B8A6' }}>查看所属类目</button>
                    </td>
                    <td className="py-2.5 px-3"><div className="flex justify-center"><MiniTrend data={item.trend} /></div></td>
                    <td className="py-2.5 px-3 text-right">
                      <div className="text-xs font-mono-num font-semibold" style={{ color: '#1C1917' }}>{item.monthlySales.toLocaleString()}</div>
                      <div className="text-[10px] font-medium" style={{ color: LC.success }}>{item.salesGrowth}</div>
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <div className="text-xs font-mono-num font-semibold" style={{ color: '#E8785A' }}>{item.monthlyRevenue.toLocaleString()}</div>
                      <div className="text-[10px] font-medium" style={{ color: LC.success }}>{item.revenueGrowth}</div>
                    </td>
                    <td className="py-2.5 px-3 text-right text-xs font-mono-num font-medium" style={{ color: '#1C1917' }}>{item.avgPrice}</td>
                    <td className="py-2.5 px-3 text-right"><span className="text-xs font-mono-num font-semibold" style={{ color: item.avgRating >= 4.5 ? LC.success : '#14B8A6' }}>{item.avgRating}</span></td>
                    <td className="py-2.5 px-3 text-right text-xs font-mono-num" style={{ color: '#78716C' }}>{item.top3Ratio}</td>
                    <td className="py-2.5 px-3 text-right text-xs font-mono-num" style={{ color: '#78716C' }}>{item.newRatio}</td>
                    <td className="py-2.5 px-3 text-center">
                      <button className="text-[10px] font-medium block mb-1" style={{ color: '#E8785A' }}>查看商品</button>
                      <button className="text-[10px] text-white px-2 py-0.5 rounded-sm font-medium" style={{ background: '#E8785A' }}>创建报告</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
