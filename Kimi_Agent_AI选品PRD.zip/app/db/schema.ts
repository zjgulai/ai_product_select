import {
  mysqlTable,
  serial,
  varchar,
  timestamp,
  int,
  json,
} from "drizzle-orm/mysql-core";

// ===== Data File Uploads (file metadata) =====
export const dataFiles = mysqlTable("data_files", {
  id: serial("id").primaryKey(),
  originalName: varchar("original_name", { length: 255 }).notNull(),
  fileName: varchar("file_name", { length: 255 }).notNull(),
  fileType: varchar("file_type", { length: 50 }).notNull(),
  fileSize: int("file_size").notNull(),
  rowCount: int("row_count").default(0),
  sheetNames: json("sheet_names").$type<string[]>().default([]),
  columns: json("columns").$type<{ name: string; type: string }[]>().default([]),
  status: varchar("status", { length: 20 }).notNull().default("active"),
  uploadedAt: timestamp("uploaded_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow().onUpdateNow(),
});

export type DataFile = typeof dataFiles.$inferSelect;

// ===== Data Templates (define available dataset schemas for the frontend) =====
export const dataTemplates = mysqlTable("data_templates", {
  id: serial("id").primaryKey(),
  dataKey: varchar("data_key", { length: 100 }).notNull().unique(),
  name: varchar("name", { length: 100 }).notNull(),
  description: varchar("description", { length: 255 }),
  page: varchar("page", { length: 50 }).notNull(),
  module: varchar("module", { length: 50 }).notNull(),
  columns: json("columns").$type<{ key: string; label: string; type: "string" | "number" | "boolean" | "json" | "date" }[]>().notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type DataTemplate = typeof dataTemplates.$inferSelect;

// ===== Dynamic Data (universal store for all page datasets) =====
export const dynamicData = mysqlTable("dynamic_data", {
  id: serial("id").primaryKey(),
  dataKey: varchar("data_key", { length: 100 }).notNull(),
  recordData: json("record_data").$type<Record<string, any>>().notNull(),
  sortOrder: int("sort_order").default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow().onUpdateNow(),
});

export type DynamicData = typeof dynamicData.$inferSelect;
