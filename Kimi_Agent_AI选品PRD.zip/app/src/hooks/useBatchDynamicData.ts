import { useMemo } from "react";
import { trpc } from "@/providers/trpc";

/**
 * Batch fetch multiple dynamic datasets by their keys.
 * Returns a record mapping dataKey -> { records, hasRealData }
 * Falls back to mock data if no DB data exists.
 */
export function useBatchDynamicData(
  requests: { dataKey: string; mockData?: any[] }[]
) {
  const utils = trpc.useUtils();

  // Use tRPC's useQueries for batch fetching
  const queryResults = trpc.useQueries((t) =>
    requests.map((req) =>
      t.dataManager.dynamic.queryByKey(
        { dataKey: req.dataKey },
        { staleTime: 5 * 60 * 1000 }
      )
    )
  );

  const results = useMemo(() => {
    const map: Record<
      string,
      { records: any[]; isLoading: boolean; hasRealData: boolean; dataKey: string }
    > = {};

    requests.forEach((req, i) => {
      const q = queryResults[i];
      const data = q.data as any[] | undefined;
      const hasRealData = !!(data && data.length > 0);
      map[req.dataKey] = {
        records: hasRealData ? data! : req.mockData ?? [],
        isLoading: q.isLoading,
        hasRealData,
        dataKey: req.dataKey,
      };
    });

    return map;
  }, [queryResults, requests]);

  const anyLoading = queryResults.some((q) => q.isLoading);
  const anyRealData = Object.values(results).some((r) => r.hasRealData);

  return { results, anyLoading, anyRealData, invalidateAll: () => utils.dataManager.dynamic.queryByKey.invalidate() };
}
